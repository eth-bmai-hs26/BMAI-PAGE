"""What models the wizard offers, and what to tell people about them.

Standard library only — this module is imported by the bootstrap server, which
runs before anything has been installed.
"""

# ── Local models (Ollama) ───────────────────────────────────────────────────
# `size_gb` is the download; `ram_gb` is roughly what the machine needs free to
# run it without swapping. The wizard greys out anything the laptop cannot hold.

LOCAL_MODELS = [
    {
        "id": "gemma3:1b",
        "label": "Gemma 3 · 1B",
        "size_gb": 0.9,
        "ram_gb": 4,
        "speed": "Fastest",
        "quality": "Basic",
        "note": "Fine for watching the agent loop work. It will get tax numbers wrong.",
    },
    {
        "id": "gemma3:4b",
        "label": "Gemma 3 · 4B",
        "size_gb": 3.3,
        "ram_gb": 8,
        "speed": "Fast",
        "quality": "Fair",
        "note": "A reasonable middle ground on a laptop with 8 GB of memory.",
    },
    {
        "id": "gemma3:12b",
        "label": "Gemma 3 · 12B",
        "size_gb": 8.1,
        "ram_gb": 16,
        "speed": "Moderate",
        "quality": "Best local",
        "note": "The most accurate option that still runs offline. Needs 16 GB.",
        "recommended": True,
    },
    {
        "id": "llama3.1:8b",
        "label": "Llama 3.1 · 8B",
        "size_gb": 4.9,
        "ram_gb": 16,
        "speed": "Moderate",
        "quality": "Good",
        "note": "Solid all-rounder; a good fallback if Gemma misbehaves.",
    },
    {
        "id": "qwen2.5:7b",
        "label": "Qwen 2.5 · 7B",
        "size_gb": 4.7,
        "ram_gb": 16,
        "speed": "Moderate",
        "quality": "Good",
        "note": "Strong at following the JSON output format the agent needs.",
    },
]

# ── Hosted models (OpenRouter) ──────────────────────────────────────────────
# The notebook students use runs on OpenRouter, so these are the same route.

OPENROUTER_MODELS = [
    {
        "id": "anthropic/claude-sonnet-4.5",
        "label": "Claude Sonnet 4.5",
        "speed": "Fast",
        "quality": "Best",
        "note": "What the student notebook uses. The most reliable choice for a demo.",
        "recommended": True,
    },
    {
        "id": "openai/gpt-4o-mini",
        "label": "GPT-4o mini",
        "speed": "Fastest",
        "quality": "Good",
        "note": "Cheapest of the hosted options and quick to respond.",
    },
    {
        "id": "google/gemini-2.5-flash",
        "label": "Gemini 2.5 Flash",
        "speed": "Fastest",
        "quality": "Good",
        "note": "Very fast; occasionally sloppy with the harder deduction rules.",
    },
    {
        "id": "anthropic/claude-haiku-4.5",
        "label": "Claude Haiku 4.5",
        "speed": "Fast",
        "quality": "Very good",
        "note": "Noticeably quicker than Sonnet, still strong on the tax rules.",
    },
]


# The operating system, a browser and Python need headroom on top of the model
# weights. Without it macOS starts swapping and the whole machine stutters, so a
# model is only "comfortable" when the machine has this much memory to spare
# beyond what the weights need.
HEADROOM_GB = 6


def local_models(installed: list[str], ram_gb: float | None) -> list[dict]:
    """Merge the curated list with whatever Ollama already has pulled.

    Models already on disk are marked ``installed`` (no download needed) and
    float to the top. Each model is also judged against this machine's memory:

    ``too_big``  the weights alone will not fit — offering it would be a trap
    ``tight``    it fits, but leaves no room for the OS, so the machine will
                 swap and feel frozen. Chosen deliberately, it still works.

    The recommendation follows the same rule: the best model that is not tight,
    rather than a fixed favourite, so a 16 GB laptop is not pointed at a model
    that needs all 16 GB.
    """
    # `ollama list` may report "gemma3:12b" or a bare "gemma3"; normalise both.
    have = set()
    for name in installed:
        parts = name.split(":")
        have.add(f"{parts[0]}:{parts[1]}" if len(parts) > 1 else parts[0])

    out = []
    for model in LOCAL_MODELS:
        entry = dict(model)
        entry.pop("recommended", None)          # decided below, from this machine
        entry["installed"] = model["id"] in have
        entry["too_big"] = bool(ram_gb and model["ram_gb"] > ram_gb)
        entry["tight"] = bool(
            ram_gb and not entry["too_big"] and model["ram_gb"] + HEADROOM_GB > ram_gb
        )
        if entry["tight"]:
            entry["note"] = (
                entry["note"] + " On this machine it leaves almost no memory for "
                "anything else, so expect it to be slow and to make the computer stutter."
            )
        out.append(entry)

    # Models the user pulled themselves that are not in the curated list.
    known = {m["id"] for m in LOCAL_MODELS}
    for model_id in sorted(have - known):
        out.append({
            "id": model_id,
            "label": model_id,
            "size_gb": None,
            "ram_gb": None,
            "speed": "Unknown",
            "quality": "Unknown",
            "note": "Already on this machine — not one of our tested models.",
            "installed": True,
            "too_big": False,
            "tight": False,
        })

    # Recommend the largest model that still leaves the machine room to breathe,
    # preferring one that is already downloaded. On a small laptop every option
    # is tight, so fall back to the smallest that at least fits — there should
    # always be a suggested choice rather than none.
    fits = [m for m in out if not m["too_big"] and m.get("ram_gb")]
    comfortable = [m for m in fits if not m["tight"]]
    if comfortable:
        max(comfortable, key=lambda m: (m["installed"], m["ram_gb"]))["recommended"] = True
    elif fits:
        min(fits, key=lambda m: (m["ram_gb"], not m["installed"]))["recommended"] = True

    # Already-downloaded first, then comfortable ones, then by descending size.
    out.sort(key=lambda m: (not m["installed"], m["too_big"], m["tight"], -(m.get("ram_gb") or 0)))
    return out
