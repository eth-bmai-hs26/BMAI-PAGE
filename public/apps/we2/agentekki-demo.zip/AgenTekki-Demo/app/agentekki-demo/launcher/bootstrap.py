"""AgenTekki launcher — the first-run wizard.

Double-clicking AgenTekki.command / AgenTekki.bat ends up here. This module uses
**only the Python standard library**, because it runs before anything has been
installed: it is what installs things.

    1. serve the wizard at http://localhost:5050
    2. set the project up, reporting progress
    3. take the model choice (OpenRouter key, or a local Ollama model)
    4. start the real app and send the browser to it

Run with --reset to forget a previous choice and show the wizard again.
"""

import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import catalog
import setup as steps

HERE = Path(__file__).resolve().parent
APP_ROOT = HERE.parent
REPO_ROOT = APP_ROOT.parent.parent

WIZARD_PORT = 5050
APP_PORT = 5001

_progress = steps.Progress()
_worker: threading.Thread | None = None
_app_process: subprocess.Popen | None = None


# ─────────────────────────────────────────────────────────────────────────────
# Launching the real application
# ─────────────────────────────────────────────────────────────────────────────

def _port_open(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(0.4)
        return probe.connect_ex((host, port)) == 0


def start_app(config: dict) -> tuple[bool, str]:
    """Start the Flask app with the chosen provider. Returns (ok, message)."""
    global _app_process

    if _port_open(APP_PORT):
        return True, f"http://localhost:{APP_PORT}"

    env = dict(os.environ)
    env["LLM_PROVIDER"] = config.get("provider", "openrouter")
    env["LLM_MODEL"] = config.get("model", "")
    if config.get("openrouter_api_key"):
        env["OPENROUTER_API_KEY"] = config["openrouter_api_key"]
    env["AGENTEKKI_SERVE_UI"] = "1"
    env["PYTHONPATH"] = os.pathsep.join([str(APP_ROOT), str(REPO_ROOT)])

    _app_process = subprocess.Popen(
        [str(steps.venv_python()), "-m", "backend.app"],
        cwd=str(APP_ROOT), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
    )

    def drain() -> None:
        assert _app_process is not None and _app_process.stdout is not None
        for line in _app_process.stdout:
            print("[app]", line.rstrip())

    threading.Thread(target=drain, daemon=True).start()

    for _ in range(60):
        if _port_open(APP_PORT):
            return True, f"http://localhost:{APP_PORT}"
        if _app_process.poll() is not None:
            return False, "The application exited while starting. See the terminal window for details."
        time.sleep(0.5)
    return False, "The application did not start within 30 seconds."


# ─────────────────────────────────────────────────────────────────────────────
# Wizard HTTP API
# ─────────────────────────────────────────────────────────────────────────────

class Wizard(BaseHTTPRequestHandler):
    server_version = "AgenTekki"

    def log_message(self, *args) -> None:  # quieter terminal
        pass

    # -- helpers ------------------------------------------------------------
    def _send(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return {}

    # -- routes -------------------------------------------------------------
    def do_GET(self) -> None:  # noqa: N802
        if self.path in ("/", "/index.html"):
            html = (HERE / "wizard.html").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(html)
            return

        if self.path == "/api/env":
            env = steps.describe_environment()
            env["config"] = {k: v for k, v in steps.load_config().items() if k != "openrouter_api_key"}
            env["has_saved_key"] = bool(steps.load_config().get("openrouter_api_key"))
            return self._send(env)

        if self.path == "/api/progress":
            return self._send(_progress.snapshot())

        if self.path == "/api/models":
            installed = steps.ollama_models()
            return self._send({
                "local": catalog.local_models(installed, steps.total_ram_gb()),
                "openrouter": catalog.OPENROUTER_MODELS,
                "ram_gb": steps.total_ram_gb(),
                "ollama_installed": steps.ollama_installed(),
            })

        return self._send({"error": "not found"}, 404)

    def do_POST(self) -> None:  # noqa: N802
        global _worker
        body = self._body()

        if self.path == "/api/prepare":
            if _worker and _worker.is_alive():
                return self._send({"started": False, "reason": "already running"})
            _worker = threading.Thread(target=steps.prepare, args=(_progress,), daemon=True)
            _worker.start()
            return self._send({"started": True})

        if self.path == "/api/verify-key":
            ok, message = steps.verify_openrouter_key(body.get("api_key", "").strip())
            return self._send({"ok": ok, "message": message})

        if self.path == "/api/pull-model":
            if _worker and _worker.is_alive():
                return self._send({"started": False, "reason": "already running"})
            model = body.get("model", "")
            _worker = threading.Thread(target=steps.pull_model, args=(model, _progress), daemon=True)
            _worker.start()
            return self._send({"started": True})

        if self.path == "/api/launch":
            config = {
                "provider": body.get("provider", "openrouter"),
                "model": body.get("model", ""),
            }
            if body.get("api_key"):
                config["openrouter_api_key"] = body["api_key"].strip()
            elif body.get("provider") == "openrouter":
                config["openrouter_api_key"] = steps.load_config().get("openrouter_api_key", "")
            steps.save_config(config)

            ok, message = start_app(config)
            return self._send({"ok": ok, "url" if ok else "message": message})

        return self._send({"error": "not found"}, 404)


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def main() -> int:
    if "--reset" in sys.argv and steps.CONFIG_PATH.exists():
        steps.CONFIG_PATH.unlink()
        print("Forgot the saved setup. The wizard will ask again.")

    if sys.version_info < (3, 10):
        print(f"AgenTekki needs Python 3.10 or newer (this is {sys.version.split()[0]}).")
        return 1

    # Already set up and configured? Skip straight to the app.
    config = steps.load_config()
    quick = config and steps.deps_installed() and (steps.DIST_DIR / "index.html").exists()
    if quick and "--wizard" not in sys.argv:
        print("Starting AgenTekki...")
        ok, message = start_app(config)
        if ok:
            print(f"\n  AgenTekki is running at {message}\n  Press Ctrl+C to stop.\n")
            webbrowser.open(message)
            try:
                while _app_process and _app_process.poll() is None:
                    time.sleep(1)
            except KeyboardInterrupt:
                pass
            return 0
        print(f"Could not start: {message}\nFalling back to the setup wizard.")

    if _port_open(WIZARD_PORT):
        url = f"http://localhost:{WIZARD_PORT}"
        print(f"The wizard is already open at {url}")
        webbrowser.open(url)
        return 0

    server = ThreadingHTTPServer(("127.0.0.1", WIZARD_PORT), Wizard)
    url = f"http://localhost:{WIZARD_PORT}"
    print(f"\n  AgenTekki setup — open {url} if your browser did not.\n  Press Ctrl+C to stop.\n")
    threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        if _app_process and _app_process.poll() is None:
            _app_process.terminate()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
