"""Environment detection and the setup steps the wizard drives.

Standard library only: this runs before anything is installed.

Two phases, matching the wizard:

    prepare()   create the virtual environment and install the Python packages
    pull_model()  download an Ollama model (only if local models were chosen)

Both report progress into a shared ``Progress`` object that the wizard polls.
"""

import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
VENV_DIR = APP_ROOT / ".venv"
CONFIG_DIR = APP_ROOT / ".agentekki"
CONFIG_PATH = CONFIG_DIR / "config.json"
DIST_DIR = APP_ROOT / "frontend" / "dist"
REQUIREMENTS = APP_ROOT / "backend" / "requirements.txt"

OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")


# ─────────────────────────────────────────────────────────────────────────────
# Environment detection
# ─────────────────────────────────────────────────────────────────────────────

def detect_os() -> str:
    """Return 'windows', 'macos' or 'linux'."""
    system = platform.system().lower()
    if system.startswith("win"):
        return "windows"
    if system == "darwin":
        return "macos"
    return "linux"


def total_ram_gb() -> float | None:
    """Total physical memory in GB, or None if it cannot be determined."""
    try:
        if hasattr(os, "sysconf") and "SC_PAGE_SIZE" in os.sysconf_names and "SC_PHYS_PAGES" in os.sysconf_names:
            return round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1024**3, 1)
    except (ValueError, OSError):
        pass
    try:
        if detect_os() == "macos":
            out = subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True, timeout=5)
            if out.returncode == 0:
                return round(int(out.stdout.strip()) / 1024**3, 1)
        if detect_os() == "windows":
            out = subprocess.run(
                ["wmic", "ComputerSystem", "get", "TotalPhysicalMemory"],
                capture_output=True, text=True, timeout=5,
            )
            digits = [int(t) for t in out.stdout.split() if t.isdigit()]
            if digits:
                return round(digits[0] / 1024**3, 1)
    except Exception:
        pass
    return None


def venv_python() -> Path:
    """Path to the interpreter inside our virtual environment."""
    if detect_os() == "windows":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def deps_installed() -> bool:
    """True when the venv exists and already has the packages we need.

    Every top-level import the app makes at runtime belongs here. If one is
    missing from this probe, a venv built before that package was added is
    reported as ready, pip is skipped, and the feature fails at the moment
    someone clicks it.
    """
    py = venv_python()
    if not py.exists():
        return False
    probe = "import flask, flask_cors, openai, rapidfuzz, fpdf"
    try:
        return subprocess.run([str(py), "-c", probe], capture_output=True, timeout=60).returncode == 0
    except Exception:
        return False


def ollama_installed() -> bool:
    return shutil.which("ollama") is not None


def ollama_running() -> bool:
    try:
        with urllib.request.urlopen(f"{OLLAMA_HOST}/api/tags", timeout=2):
            return True
    except Exception:
        return False


def ensure_ollama_running(wait: float = 6.0) -> bool:
    """Start the Ollama service if it is installed but not answering.

    Both the HTTP API and `ollama list` need the daemon, so without this a
    machine with models already on disk would be told it has none.
    """
    if ollama_running():
        return True
    if not ollama_installed():
        return False
    try:
        subprocess.Popen(["ollama", "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        return False
    deadline = time.monotonic() + wait
    while time.monotonic() < deadline:
        if ollama_running():
            return True
        time.sleep(0.3)
    return False


def ollama_models() -> list[str]:
    """Names of models already pulled, via the HTTP API then the CLI."""
    ensure_ollama_running()
    try:
        with urllib.request.urlopen(f"{OLLAMA_HOST}/api/tags", timeout=3) as r:
            data = json.loads(r.read().decode("utf-8"))
        return [m["name"] for m in data.get("models", [])]
    except Exception:
        pass
    if not ollama_installed():
        return []
    try:
        out = subprocess.run(["ollama", "list"], capture_output=True, text=True, timeout=10)
        return [line.split()[0] for line in out.stdout.splitlines()[1:] if line.strip()]
    except Exception:
        return []


def describe_environment() -> dict:
    """Everything the wizard's first screen needs."""
    return {
        "os": detect_os(),
        "os_label": {"windows": "Windows", "macos": "macOS", "linux": "Linux"}[detect_os()],
        "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "ram_gb": total_ram_gb(),
        "venv_ready": venv_python().exists(),
        "deps_ready": deps_installed(),
        "ui_ready": (DIST_DIR / "index.html").exists(),
        "ollama_installed": ollama_installed(),
        "ollama_running": ollama_running(),
        "ollama_models": ollama_models(),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Progress reporting
# ─────────────────────────────────────────────────────────────────────────────

class Progress:
    """Thread-safe record of setup steps, polled by the wizard."""

    def __init__(self):
        self._lock = threading.Lock()
        self.steps: list[dict] = []
        self.done = False
        self.error: str | None = None
        self.log: list[str] = []

    def define(self, names: list[tuple[str, str]]) -> None:
        with self._lock:
            self.steps = [
                {"key": k, "label": label, "state": "waiting", "detail": "", "percent": None}
                for k, label in names
            ]
            self.done = False
            self.error = None

    def start(self, key: str, detail: str = "") -> None:
        self._set(key, state="running", detail=detail)

    def update(self, key: str, detail: str = "", percent: int | None = None) -> None:
        self._set(key, detail=detail, percent=percent)

    def finish(self, key: str, detail: str = "") -> None:
        self._set(key, state="done", detail=detail, percent=100)

    def skip(self, key: str, detail: str) -> None:
        self._set(key, state="skipped", detail=detail)

    def fail(self, key: str, detail: str) -> None:
        self._set(key, state="failed", detail=detail)
        with self._lock:
            self.error = detail
            self.done = True

    def complete(self) -> None:
        with self._lock:
            self.done = True

    def note(self, line: str) -> None:
        with self._lock:
            self.log.append(line.rstrip())
            del self.log[:-200]

    def _set(self, key: str, **fields) -> None:
        with self._lock:
            for step in self.steps:
                if step["key"] == key:
                    step.update({k: v for k, v in fields.items() if v is not None or k == "percent"})
                    return

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "steps": [dict(s) for s in self.steps],
                "done": self.done,
                "error": self.error,
                "log": list(self.log[-40:]),
            }


# ─────────────────────────────────────────────────────────────────────────────
# Phase 1 — prepare the project
# ─────────────────────────────────────────────────────────────────────────────

def _run(cmd: list[str], progress: Progress, key: str, timeout: int = 1800) -> int:
    """Run a command, streaming its output into the progress log."""
    progress.note(f"$ {' '.join(cmd)}")
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, bufsize=1, cwd=str(APP_ROOT),
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip()
        if line:
            progress.note(line)
            progress.update(key, detail=line[:110])
    proc.wait(timeout=timeout)
    return proc.returncode


def prepare(progress: Progress) -> None:
    """Create the venv and install Python packages. Runs in a worker thread."""
    progress.define([
        ("venv", "Creating an isolated Python environment"),
        ("deps", "Installing the Python packages"),
        ("ui", "Preparing the tax portal interface"),
        ("verify", "Checking everything works"),
    ])

    try:
        # ── venv ────────────────────────────────────────────────────────────
        progress.start("venv")
        if venv_python().exists():
            progress.skip("venv", "Already set up")
        else:
            if _run([sys.executable, "-m", "venv", str(VENV_DIR)], progress, "venv") != 0:
                return progress.fail("venv", "Could not create the virtual environment.")
            progress.finish("venv", "Created")

        # ── dependencies ────────────────────────────────────────────────────
        progress.start("deps", "This is the slow part — a minute or two.")
        if deps_installed():
            progress.skip("deps", "Already installed")
        else:
            py = str(venv_python())
            _run([py, "-m", "pip", "install", "--upgrade", "pip", "--quiet"], progress, "deps")
            code = _run([py, "-m", "pip", "install", "-r", str(REQUIREMENTS)], progress, "deps")
            if code != 0:
                return progress.fail("deps", "pip could not install the packages — see the log below.")
            progress.finish("deps", "Installed")

        # ── frontend ────────────────────────────────────────────────────────
        progress.start("ui")
        if (DIST_DIR / "index.html").exists():
            progress.skip("ui", "Already built")
        elif shutil.which("npm"):
            progress.update("ui", "Building with npm — this takes a moment.")
            fe = APP_ROOT / "frontend"
            if subprocess.run(["npm", "install", "--no-audit", "--no-fund"], cwd=str(fe)).returncode != 0:
                return progress.fail("ui", "npm install failed.")
            if subprocess.run(["npm", "run", "build"], cwd=str(fe)).returncode != 0:
                return progress.fail("ui", "npm run build failed.")
            progress.finish("ui", "Built")
        else:
            return progress.fail(
                "ui",
                "The interface has not been built and Node.js is not installed. "
                "Ask a TA for a copy that includes frontend/dist.",
            )

        # ── verify ──────────────────────────────────────────────────────────
        progress.start("verify")
        check = subprocess.run(
            [str(venv_python()), "-c",
             "import sys; sys.path[:0]=['.','../..']; from backend.app import create_app; create_app(); print('ok')"],
            capture_output=True, text=True, cwd=str(APP_ROOT), timeout=120,
        )
        if check.returncode != 0:
            progress.note(check.stderr[-2000:])
            return progress.fail("verify", "The app could not start — see the log below.")
        progress.finish("verify", "Ready")
        progress.complete()

    except Exception as exc:  # noqa: BLE001 — surface anything to the wizard
        progress.fail("verify", f"Unexpected error: {exc}")


# ─────────────────────────────────────────────────────────────────────────────
# Phase 2 — download a local model
# ─────────────────────────────────────────────────────────────────────────────

_PERCENT = re.compile(r"(\d{1,3})%")


def pull_model(model_id: str, progress: Progress) -> None:
    """Make sure Ollama is running and the chosen model is downloaded."""
    progress.define([
        ("ollama", "Checking Ollama"),
        ("model", f"Downloading {model_id}"),
    ])

    try:
        progress.start("ollama")
        if not ollama_installed():
            return progress.fail(
                "ollama",
                "Ollama is not installed. Get it from https://ollama.com/download, "
                "then come back to this page and press Retry.",
            )
        if not ollama_running():
            progress.update("ollama", "Starting the Ollama service...")
        if not ensure_ollama_running(wait=10):
            return progress.fail("ollama", "Could not reach Ollama. Try running `ollama serve` in a terminal.")
        progress.finish("ollama", "Running")

        progress.start("model")
        if model_id in ollama_models():
            progress.skip("model", "Already downloaded")
            return progress.complete()

        proc = subprocess.Popen(
            ["ollama", "pull", model_id],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            line = line.strip()
            if not line:
                continue
            progress.note(line)
            match = _PERCENT.search(line)
            progress.update("model", detail=line[:110],
                            percent=int(match.group(1)) if match else None)
        proc.wait()
        if proc.returncode != 0:
            return progress.fail("model", f"Could not download {model_id}.")
        progress.finish("model", "Downloaded")
        progress.complete()

    except Exception as exc:  # noqa: BLE001
        progress.fail("model", f"Unexpected error: {exc}")


# ─────────────────────────────────────────────────────────────────────────────
# Saved choices
# ─────────────────────────────────────────────────────────────────────────────

def save_config(config: dict) -> None:
    """Persist the provider/model choice next to the app (never committed)."""
    CONFIG_DIR.mkdir(exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding="utf-8")
    try:
        # The file may hold an API key — keep it to the owner.
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass


def load_config() -> dict:
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def verify_openrouter_key(api_key: str) -> tuple[bool, str]:
    """Check a key against OpenRouter. Returns (ok, message)."""
    request = urllib.request.Request(
        "https://openrouter.ai/api/v1/key",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            json.loads(response.read().decode("utf-8"))
        return True, "Key accepted."
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            return False, "OpenRouter rejected that key. Check it was copied in full."
        return False, f"OpenRouter returned HTTP {exc.code}."
    except urllib.error.URLError:
        return False, "Could not reach OpenRouter. Are you online?"
    except Exception as exc:  # noqa: BLE001
        return False, f"Could not check the key: {exc}"
