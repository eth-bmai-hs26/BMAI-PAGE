#!/bin/bash
# AgenTekki — double-click this file to start.
#
# Plain bash on purpose: this has to run on a machine where nothing is
# installed yet. It finds a usable Python, downloading a self-contained one if
# there isn't one, then hands over to the setup wizard.

cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1

BOLD=$'\033[1m'; DIM=$'\033[2m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'; RESET=$'\033[0m'
echo ""
echo "${BOLD}  AgenTekki${RESET}"
echo "${DIM}  Zurich tax return, filed by an AI agent${RESET}"
echo ""

MIN_MINOR=10          # we need Python 3.10+
VENDOR_DIR=".agentekki/python"

usable() {
    [ -x "$1" ] || command -v "$1" >/dev/null 2>&1 || return 1
    "$1" -c "import sys; sys.exit(0 if sys.version_info >= (3, $MIN_MINOR) else 1)" >/dev/null 2>&1
}

PYTHON=""
for candidate in "$VENDOR_DIR/bin/python3" python3 python3.13 python3.12 python3.11 python3.10 python \
                 /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
    if usable "$candidate"; then PYTHON="$candidate"; break; fi
done

# ── Nothing usable: fetch a self-contained Python just for AgenTekki ────────
if [ -z "$PYTHON" ]; then
    echo "  ${YELLOW}No suitable Python found.${RESET}"
    echo "  Downloading a private copy just for AgenTekki (about 30 MB)."
    echo "  ${DIM}Nothing is installed system-wide; it all lives in this folder.${RESET}"
    echo ""

    case "$(uname -s)-$(uname -m)" in
        Darwin-arm64)  TRIPLE="aarch64-apple-darwin" ;;
        Darwin-x86_64) TRIPLE="x86_64-apple-darwin" ;;
        Linux-aarch64) TRIPLE="aarch64-unknown-linux-gnu" ;;
        Linux-x86_64)  TRIPLE="x86_64-unknown-linux-gnu" ;;
        *)
            echo "  Unsupported system: $(uname -s) $(uname -m)."
            echo "  Please install Python 3.$MIN_MINOR or newer from https://www.python.org/downloads/"
            echo ""; read -r -p "  Press Return to close." _; exit 1 ;;
    esac

    RELEASE="20241016"
    URL="https://github.com/indygreg/python-build-standalone/releases/download/${RELEASE}/cpython-3.12.7+${RELEASE}-${TRIPLE}-install_only.tar.gz"

    mkdir -p .agentekki
    if ! curl -fL --progress-bar "$URL" -o .agentekki/python.tar.gz; then
        echo ""
        echo "  ${YELLOW}Could not download Python.${RESET}"
        echo "  Install it yourself from https://www.python.org/downloads/ and run this again."
        echo ""; read -r -p "  Press Return to close." _; exit 1
    fi
    tar -xzf .agentekki/python.tar.gz -C .agentekki && rm -f .agentekki/python.tar.gz
    PYTHON="$VENDOR_DIR/bin/python3"

    if ! usable "$PYTHON"; then
        echo "  ${YELLOW}The downloaded Python did not work.${RESET}"
        echo "  Install Python from https://www.python.org/downloads/ and run this again."
        echo ""; read -r -p "  Press Return to close." _; exit 1
    fi
    echo "  ${GREEN}Python ready.${RESET}"
    echo ""
fi

echo "  ${DIM}Using $("$PYTHON" -c 'import sys; print("Python", sys.version.split()[0])')${RESET}"
echo ""

# -u so progress reaches the Terminal window as it happens.
"$PYTHON" -u launcher/bootstrap.py "$@"
STATUS=$?

# 130 = Ctrl+C, 143 = terminated. Both are how you are *meant* to stop it, so
# they are not errors — only an unexpected exit should keep the window open.
case $STATUS in
    0|130|143)
        echo ""
        echo "  ${DIM}AgenTekki stopped.${RESET}"
        echo ""
        ;;
    *)
        echo ""
        echo "  ${YELLOW}AgenTekki stopped with an error (code $STATUS).${RESET}"
        echo "  The messages above usually say why."
        echo ""
        read -r -p "  Press Return to close this window." _
        ;;
esac
