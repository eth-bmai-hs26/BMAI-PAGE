@echo off
rem AgenTekki - double-click this file to start.
rem
rem Plain batch on purpose: this has to run on a machine where nothing is
rem installed yet. It finds a usable Python, downloading a self-contained one
rem if there isn't one, then hands over to the setup wizard.

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo   AgenTekki
echo   Zurich tax return, filed by an AI agent
echo.

set "PYTHON="
set "VENDOR=.agentekki\python\python.exe"

rem -- A copy we downloaded earlier? ------------------------------------------
if exist "%VENDOR%" (
    "%VENDOR%" -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1
    if !errorlevel! equ 0 set "PYTHON=%VENDOR%"
)

rem -- The py launcher, then plain python -------------------------------------
if not defined PYTHON (
    py -3 -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1
    if !errorlevel! equ 0 set "PYTHON=py -3"
)
if not defined PYTHON (
    python -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1
    if !errorlevel! equ 0 set "PYTHON=python"
)

rem -- Nothing usable: fetch a private copy -----------------------------------
if not defined PYTHON (
    echo   No suitable Python found.
    echo   Downloading a private copy just for AgenTekki ^(about 30 MB^).
    echo   Nothing is installed system-wide; it all lives in this folder.
    echo.

    set "ARCH=x86_64"
    if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=aarch64"
    set "REL=20241016"
    set "URL=https://github.com/indygreg/python-build-standalone/releases/download/!REL!/cpython-3.12.7+!REL!-!ARCH!-pc-windows-msvc-install_only.tar.gz"

    if not exist ".agentekki" mkdir ".agentekki"
    curl -fL --progress-bar "!URL!" -o ".agentekki\python.tar.gz"
    if !errorlevel! neq 0 (
        echo.
        echo   Could not download Python.
        echo   Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^)
        echo   and run this file again.
        echo.
        pause
        exit /b 1
    )
    tar -xzf ".agentekki\python.tar.gz" -C ".agentekki"
    del ".agentekki\python.tar.gz" >nul 2>&1

    if exist "%VENDOR%" set "PYTHON=%VENDOR%"
)

if not defined PYTHON (
    echo.
    echo   Python could not be set up automatically.
    echo   Install it from https://www.python.org/downloads/
    echo   Remember to tick "Add python.exe to PATH" during installation.
    echo.
    pause
    exit /b 1
)

echo.

rem -u so progress reaches this window as it happens.
%PYTHON% -u launcher\bootstrap.py %*
rem Ctrl+C reports code 2 or -1073741510 on Windows; neither is a real error,
rem so only keep the window open when something actually went wrong.
if %errorlevel% equ 0 goto :stopped
if %errorlevel% equ 2 goto :stopped
if %errorlevel% equ -1073741510 goto :stopped
echo.
echo   AgenTekki stopped with an error (code %errorlevel%).
echo   The messages above usually say why.
echo.
pause
goto :done

:stopped
echo.
echo   AgenTekki stopped.
echo.

:done
endlocal
