"""The agent brain — the same plan-then-execute loop students build.

This mirrors the ``think_step`` and ``think_loop`` students write in the exercise
notebook, so the demo shows the exercise's architecture rather than a simplified
one:

    Phase 1 (Plan)     the model sees field labels plus a catalog of document and
                       guide *names* — never their content — and decides what to read
    Retrieval          only the documents and guides the plan asked for are read
    Phase 2 (Execute)  the model sees its plan plus that content, and returns
                       {locator: value} mappings

The prompts and context caps live in ``exercise_prompts.py``, the same ones the
exercise notebook uses. The only thing added here is the
taxpayer (``ask_user``) exchange that drives the on-screen popup, and SSE logging
so the browser can follow along.
"""

import json
import logging
import re
import time
from pathlib import Path

from backend.services.exercise_prompts import (
    EXECUTE_SYSTEM_PROMPT,
    MAX_DOC_CHARS,
    MAX_GUIDE_CHARS,
    MAX_STRUCTURED_CHARS,
    PLAN_SYSTEM_PROMPT,
    SECTION_PROMPTS,
)

logger = logging.getLogger("think_service")


# ── Guides (same helpers as notebook sections 3 and 6) ──────────────────────

def html_to_text(raw: str) -> str:
    """Turn a guide file into readable plain text: drop <style>/<script>, strip tags."""
    text = re.sub(r"<(style|script)[^>]*>.*?</\1>", " ", raw, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    text = re.sub(r"[ \t]+", " ", text)
    return re.sub(r"\n\s*\n+", "\n", text).strip()


def load_all_guides(guides_folder) -> dict:
    """Read every guide once, as plain text, keyed by topic (the file stem)."""
    guides: dict[str, str] = {}
    folder = Path(guides_folder) if guides_folder else None
    if folder is None or not folder.exists():
        return guides
    for f in sorted(folder.iterdir()):
        if f.suffix in (".html", ".txt", ".md"):
            guides[f.stem] = html_to_text(f.read_text(encoding="utf-8"))
    return guides


def load_guide_catalog(guides_folder) -> dict:
    """Load guide descriptions from guide_catalog.json."""
    if not guides_folder:
        return {}
    catalog_path = Path(guides_folder) / "guide_catalog.json"
    if not catalog_path.exists():
        return {}
    raw = json.loads(catalog_path.read_text(encoding="utf-8"))
    return {
        name: f"{entry['description']} Use when: {entry['use_when']}"
        for name, entry in raw.items()
    }


def _clip(text: str, limit: int, label: str) -> str:
    """Cut `text` to `limit` characters, and say so when it happens."""
    if len(text) <= limit:
        return text
    logger.warning("%s: %d chars, only the first %d are sent to the model",
                   label, len(text), limit)
    return text[:limit] + "\n[... truncated ...]"


# ── Message builders (mirroring notebook tasks 2 and 3) ─────────────────────

def _history_text(filled_history: dict) -> str:
    lines = []
    for prev_page, prev_fields in filled_history.items():
        entries = ", ".join(
            f"{k}={v}" for k, v in prev_fields.items() if not str(k).startswith("_")
        )
        if entries:
            lines.append(f"  {prev_page}: {entries}")
    return "\n".join(lines) if lines else "  (none yet)"


def build_plan_user_message(page_name, fields, catalog, guides_list,
                            guide_catalog, filled_history) -> str:
    """Build the user message for the PLAN phase."""
    fillable = [f for f in fields if f.get("type") not in ("button", "text")]
    fields_desc = json.dumps(fillable, indent=2)

    catalog_text = "\n".join(f"- {d['filename']}: {d['description']}" for d in catalog)

    guides_text_lines = []
    for g in guides_list:
        desc = guide_catalog.get(g, "")
        guides_text_lines.append(f"- {g}: {desc}" if desc else f"- {g}")
    guides_text = "\n".join(guides_text_lines) if guides_text_lines else "(no guides available)"

    return f"""\
        ## Current Page: {page_name}

        ### Fields on this page:
        {fields_desc}

        ### Available Documents (names and descriptions only):
        {catalog_text}

        ### Available Tax Guides (names and descriptions — request any that may contain rules relevant to this page):
        {guides_text}

        ### Previously Filled Fields:
        {_history_text(filled_history)}

        Analyze the fields above. Decide which documents AND guides you need to read and outline your strategy.
        Respond with JSON only."""


def build_execute_user_message(page_name, fields, plan, doc_contents,
                               guide_contents, filled_history) -> str:
    """Build the user message for the EXECUTE phase."""
    fillable = [f for f in fields if f.get("type") not in ("button", "text")]
    fields_desc = json.dumps(fillable, indent=2)

    docs_text = "\n\n".join(
        f"=== {name} ===\n{_clip(content, MAX_DOC_CHARS, f'document {name}')}"
        for name, content in doc_contents.items()
    )
    guides_text = "\n\n".join(
        f"=== {name} ===\n{_clip(content, MAX_GUIDE_CHARS, f'guide {name}')}"
        for name, content in guide_contents.items()
    )
    plan_text = json.dumps(plan, indent=2) if isinstance(plan, dict) else str(plan)

    return f"""\
        ## Your Plan (from planning phase)
        {plan_text}

        ## Document Contents (the actual data you requested)
        {docs_text}

        {"## Tax Guides" + chr(10) + guides_text if guides_text else ""}

        ## Previously Filled Fields
        {_history_text(filled_history)}

        ## Current Page: {page_name}
        ### Fields on this page:
        {fields_desc}

        Now fill the fields. Return a JSON object mapping locators to values.
        If no fields apply, return empty braces."""


# ── One page: plan -> retrieve -> execute ───────────────────────────────────

def think_step(server, llm, page_name, elements, catalog, all_guides,
               guide_catalog, filled_history, section_prompts, log=print):
    """Plan-then-Execute reasoning for one page. Returns (plan, mapping)."""
    fields = [e for e in elements if e.get("type") not in ("button", "text")]
    if not fields:
        return {}, {}

    guides_list = list(all_guides.keys())

    # ── Phase 1: PLAN ────────────────────────────────────────────
    plan = llm.chat_json(PLAN_SYSTEM_PROMPT, build_plan_user_message(
        page_name, elements, catalog, guides_list, guide_catalog, filled_history))

    log(f"  🗺️ Plan: needs docs {plan.get('documents_needed', [])}")
    if plan.get("guides_needed"):
        log(f"  📚 Plan: needs guides {plan.get('guides_needed')}")
    if plan.get("strategy"):
        log(f"  💡 Strategy: {plan['strategy']}")

    # ── Selective retrieval: only what the plan asked for ────────
    doc_contents = {}
    for doc_name in plan.get("documents_needed", []):
        try:
            doc = server.read_document(doc_name)
            content = doc.get("content", "")
            if doc.get("structured"):
                content += "\n\n[Structured data]:\n" + _clip(
                    json.dumps(doc["structured"], indent=2, ensure_ascii=False),
                    MAX_STRUCTURED_CHARS, f"structured data of {doc_name}")
            doc_contents[doc_name] = content
            log(f"    📄 Read {doc_name} ({len(content)} chars)")
        except Exception as exc:
            log(f"    ⚠️ Could not read {doc_name}: {exc}")

    guide_contents = {}
    for guide_name in plan.get("guides_needed", []):
        if guide_name in all_guides:
            guide_contents[guide_name] = all_guides[guide_name]
            log(f"    📖 Loaded guide {guide_name}")
        else:
            for key in all_guides:
                if guide_name.lower() in key.lower() or key.lower() in guide_name.lower():
                    guide_contents[key] = all_guides[key]
                    log(f"    📖 Loaded guide (fuzzy) {key}")
                    break

    # ── Phase 2: EXECUTE ─────────────────────────────────────────
    section = page_name.split("/")[0]
    system_msg = EXECUTE_SYSTEM_PROMPT + "\n" + section_prompts.get(section, "")
    mapping = llm.chat_json(system_msg, build_execute_user_message(
        page_name, elements, plan, doc_contents, guide_contents, filled_history))

    return plan, mapping


# ── Dynamic rows ────────────────────────────────────────────────────────────

def add_rows_if_needed(server, elements, num_rows_needed: int = 0):
    """Click 'add row' until the page has as many rows as the plan asked for."""
    add_btns = [e for e in elements
                if e.get("type") == "button"
                and "add-row" in (e.get("locator") or "").lower()]
    if not add_btns:
        return None

    existing_rows: set[int] = set()
    for e in elements:
        match = re.search(r"-(\d+)-", e.get("locator") or "")
        if match:
            existing_rows.add(int(match.group(1)))

    rows_to_add = max(0, (num_rows_needed or 1) - len(existing_rows))
    if rows_to_add <= 0:
        return None

    for _ in range(rows_to_add):
        for btn in add_btns:
            if btn.get("locator"):
                server.click_element(btn["locator"])
    return server.scan_page()


# ── The full loop ───────────────────────────────────────────────────────────

def think(server, persona_folder: str, llm, guides_dir=None, sse_queue=None,
          max_steps: int = 100, ask_user_pause: float = 6.0) -> dict:
    """Run the agent over every page of the form.

    Parameters
    ----------
    server : MCPServer
        Server with the FlaskBridge attached.
    llm : mcp_server.llm_service.LLMService
        The same LLM wrapper the notebook uses.
    guides_dir : Path | None
        The repository's ``guides/`` folder.
    sse_queue : queue.Queue | None
        When given, every log line is streamed to the browser.
    ask_user_pause : float
        Seconds to hold the taxpayer popup open so viewers can read it.

    Returns
    -------
    dict with keys: submission, filled_history, plans, log
    """
    from mcp_server.doc_catalog import build_document_catalog

    persona_path = Path(persona_folder)
    log_lines: list[str] = []

    def log(msg: str) -> None:
        logger.info(msg)
        log_lines.append(msg)
        if sse_queue is not None:
            try:
                sse_queue.put_nowait({"type": "log", "message": msg})
            except Exception:
                pass

    log(f"📌 Agent starting for persona: {persona_path.name}")

    catalog = build_document_catalog(server)
    log(f"📂 {len(catalog)} documents available (names only until the plan asks for them)")

    all_guides = load_all_guides(guides_dir)
    guide_catalog = load_guide_catalog(guides_dir)
    log(f"📚 {len(all_guides)} guides available: {', '.join(sorted(all_guides)) or '(none)'}")

    filled_history: dict = {}
    plans: list[dict] = []
    total_fields = 0

    def fill_page(mapping: dict, page_name: str) -> dict:
        nonlocal total_fields
        filled = {}
        thought = mapping.pop("_thought", None)
        if thought:
            log(f"  🧠 {thought}")
        for locator, value in mapping.items():
            if str(locator).startswith("_"):
                continue
            result = server.fill_field(locator, str(value))
            if result.get("success"):
                filled[locator] = value
                total_fields += 1
                log(f"  ✅ {locator} = {value}")
            else:
                log(f"  ❌ {locator}: {result.get('error', 'unknown error')}")
        if filled:
            filled_history[page_name] = filled
        return filled

    def run_think_step(page_name, elements):
        """think_step plus the taxpayer exchange that drives the popup."""
        plan, mapping = think_step(
            server, llm, page_name, elements, catalog, all_guides,
            guide_catalog, filled_history, SECTION_PROMPTS, log=log,
        )

        asked = 0
        while "_ask_user" in mapping and asked < 3:
            asked += 1
            question = mapping.pop("_ask_user")
            if isinstance(question, list):
                question = question[0] if question else ""
            if not question:
                break
            log(f"  ❓ Agent asks: {question}")

            # Show the question first, then the answer, so the popup animates.
            try:
                server._bridge.notify_ask_user(question, "")
            except Exception:
                pass

            answer = server.ask_user(question)["answer"]
            log(f"  💬 Taxpayer: {answer}")

            try:
                server._bridge.notify_ask_user(question, answer)
                time.sleep(ask_user_pause)
            except Exception:
                pass

            _, mapping = think_step(
                server, llm, page_name, elements, catalog, all_guides,
                guide_catalog, filled_history, SECTION_PROMPTS, log=log,
            )

        return plan, mapping

    # Auto-navigate away from root/overview
    initial = server.scan_page()
    if initial.get("page_name", "") in ("root", "overview", ""):
        for loc in ["tab-nav-form", "btn-nav-personal", "btn-login"]:
            r = server.click_element(loc)
            if r.get("success") and r.get("new_page"):
                break

    visited: set[str] = set()
    step = 0

    while step < max_steps:
        step += 1
        page_data = server.scan_page()
        page_name = page_data.get("page_name", "unknown")
        elements = page_data.get("elements", [])

        if page_name in ("root", "overview", ""):
            server.click_element("tab-nav-form")
            continue

        if page_name in visited:
            if not server.click_element("btn-next").get("new_page"):
                break
            continue
        visited.add(page_name)

        log(f"--- Page {step}: {page_name} ---")

        if page_name == "review":
            log("📋 Review page reached — submitting...")
            result = server.submit_form()
            log(f"✅ Submitted. {total_fields} fields filled across {step} pages.")
            return {"submission": result, "filled_history": filled_history,
                    "plans": plans, "log": log_lines}

        fillable = [e for e in elements if e.get("type") not in ("button", "text")]
        has_add_row = any(
            e.get("type") == "button" and "add-row" in (e.get("locator") or "").lower()
            for e in elements
        )
        if not fillable and has_add_row:
            new_scan = add_rows_if_needed(server, elements)
            if new_scan:
                elements = new_scan.get("elements", [])
            fillable = [e for e in elements if e.get("type") not in ("button", "text")]

        if not fillable:
            log("  ⏭️ No fillable fields — skipping")
        else:
            log(f"  📝 {len(fillable)} fillable fields")
            plan, mapping = run_think_step(page_name, elements)

            if plan:
                plans.append({"page": page_name, "plan": plan})
                if sse_queue is not None:
                    try:
                        sse_queue.put_nowait({"type": "plan", "page": page_name, "plan": plan})
                    except Exception:
                        pass

            rows_needed = int(mapping.pop("_rows_needed", 0) or 0)
            if rows_needed > 0:
                new_scan = add_rows_if_needed(server, elements, rows_needed)
                if new_scan:
                    elements = new_scan.get("elements", [])
                    _, mapping = run_think_step(page_name, elements)
                    mapping.pop("_rows_needed", None)

            if mapping:
                fill_page(mapping, page_name)
            else:
                log("  ⏭️ Nothing to fill on this page")

        nav_result = server.click_element("btn-next")
        if nav_result.get("success") and nav_result.get("new_page"):
            log(f"  ➡️ {nav_result['new_page']}")
        else:
            for nav_target in ["tab-nav-form", "nav-personal", "nav-income",
                               "nav-deductions", "nav-wealth",
                               "nav-attachments", "nav-review"]:
                r = server.click_element(nav_target)
                if r.get("success") and r.get("new_page"):
                    log(f"  ➡️ {r['new_page']}")
                    break
            else:
                log("  ❌ Cannot navigate further — stopping")
                break

    log(f"⚠️ Max steps ({max_steps}) reached without submitting.")
    return {"submission": None, "filled_history": filled_history,
            "plans": plans, "log": log_lines}
