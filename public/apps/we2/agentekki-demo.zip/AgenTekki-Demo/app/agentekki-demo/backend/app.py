"""Flask application factory."""

import os
from pathlib import Path

from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS

from backend.routes.personas import bp as personas_bp
from backend.routes.agent_routes import bp as agent_bp

DIST_DIR = Path(__file__).resolve().parent.parent / "frontend" / "dist"


def create_app() -> Flask:
    app = Flask(__name__)
    CORS(app, origins=[
        "http://localhost:5173", "http://127.0.0.1:5173",
        "http://localhost:3000", "http://localhost:5001",
    ])

    app.register_blueprint(personas_bp)
    app.register_blueprint(agent_bp)

    # Serve the built React app from the same origin, so participants never
    # need Node.js — the launcher ships frontend/dist and points a browser here.
    # During development `npm run dev` on :5173 talks to this server via CORS.
    if DIST_DIR.exists():
        @app.route("/", defaults={"path": ""})
        @app.route("/<path:path>")
        def serve_ui(path: str):
            if path.startswith("api/"):
                return jsonify({"error": "not found"}), 404
            candidate = DIST_DIR / path
            if path and candidate.is_file():
                return send_from_directory(DIST_DIR, path)
            # Unknown paths fall through to index.html for client-side routing.
            return send_from_directory(DIST_DIR, "index.html")

    return app


if __name__ == "__main__":
    debug = os.environ.get("AGENTEKKI_DEBUG") == "1"
    create_app().run(host="127.0.0.1", port=5001, debug=debug, threaded=True)
