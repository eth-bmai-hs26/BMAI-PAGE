"""Render a filed return as a Zurich-style tax form PDF.

The agent fills a web form; this lays the same values out the way the canton's
paper Steuererklärung does — numbered lines (Ziffern), Swiss thousands
separators, income and deduction subtotals, and a wealth statement.

It is a simulation built from fictional taxpayers, and says so in the footer.
Nothing here computes tax owed: the tariff is out of scope and inventing a
figure would be worse than leaving it out.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from fpdf import FPDF

ARMS = Path(__file__).resolve().parent.parent.parent / "frontend" / "public" / "ZurichLogo.png"

INK = (0, 0, 0)
QUIET = (90, 100, 114)
RULE = (190, 196, 205)
ZURICH = (19, 56, 206)

MARITAL = {
    "single": "ledig", "married": "verheiratet", "divorced": "geschieden",
    "widowed": "verwitwet", "separated": "getrennt",
    "ledig": "ledig", "verheiratet": "verheiratet",
}


# ── helpers ─────────────────────────────────────────────────────────────────

def _num(value: Any) -> float | None:
    """Parse a form value into a number, or None when it is blank."""
    if value is None or isinstance(value, bool):
        return None
    text = str(value).strip().replace("'", "").replace(",", "")
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def chf(value: Any) -> str:
    """Swiss money formatting: 1'234'567.85."""
    n = _num(value)
    if n is None:
        return ""
    whole, frac = divmod(round(abs(n) * 100), 100)
    grouped = f"{whole:,}".replace(",", "'")
    return f"{'-' if n < 0 else ''}{grouped}.{frac:02d}"


def _get(data: dict, path: str) -> Any:
    node: Any = data
    for part in path.split("."):
        if not isinstance(node, dict):
            return None
        node = node.get(part)
    return node


def _date(value: Any) -> str:
    text = str(value or "").strip()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(text, fmt).strftime("%d.%m.%Y")
        except ValueError:
            continue
    return text


# The built-in Helvetica is latin-1, which covers German umlauts but not
# typographic punctuation. Persona documents and agent output contain both, so
# fold the few characters that fall outside it rather than embedding a font.
_SUBSTITUTIONS = str.maketrans({
    "—": "-", "–": "-", "−": "-",      # em/en dash, minus
    "‘": "'", "’": "'", "‚": ",",      # single quotes
    "“": '"', "”": '"', "„": '"',      # double quotes
    "…": "...", " ": " ", " ": " ",    # ellipsis, nbsp
    "•": "-", "→": "->", "€": "EUR",
})


class TaxFormPDF(FPDF):
    """A4 portrait, laid out like the cantonal return."""

    def normalize_text(self, text: str) -> str:  # type: ignore[override]
        text = str(text).translate(_SUBSTITUTIONS)
        # Anything still outside latin-1 (a name in another script, say) is
        # dropped rather than raising — a missing glyph beats a failed export.
        text = text.encode("latin-1", "replace").decode("latin-1")
        return super().normalize_text(text)

    def __init__(self, tax_year: int):
        super().__init__(orientation="P", unit="mm", format="A4")
        self.tax_year = tax_year
        self.set_auto_page_break(auto=True, margin=20)
        self.set_margins(18, 16, 18)
        self.set_title(f"Steuererklärung {tax_year}")

    # -- chrome ------------------------------------------------------------
    def footer(self) -> None:
        self.set_y(-15)
        self.set_font("Helvetica", size=7)
        self.set_text_color(*QUIET)
        self.cell(0, 4,
                  "Simulation for teaching purposes — fictional taxpayer, not an official filing.",
                  align="L")
        self.set_x(-30)
        self.cell(12, 4, f"Seite {self.page_no()}", align="R")

    def letterhead(self) -> None:
        if ARMS.exists():
            self.image(str(ARMS), x=18, y=14, h=11)
        self.set_xy(33, 14)
        self.set_font("Helvetica", "B", 9)
        self.set_text_color(*INK)
        self.cell(0, 4, "Kanton Zürich", ln=1)
        self.set_x(33)
        self.set_font("Helvetica", size=8)
        self.set_text_color(*QUIET)
        self.cell(0, 4, "Kantonales Steueramt", ln=1)

        self.set_xy(18, 32)
        self.set_font("Helvetica", "B", 18)
        self.set_text_color(*INK)
        self.cell(120, 9, f"Steuererklärung {self.tax_year}")
        self.set_font("Helvetica", size=8)
        self.set_text_color(*QUIET)
        self.cell(0, 9, "Formular 1", align="R", ln=1)
        self.set_x(18)
        self.set_font("Helvetica", size=9)
        self.cell(0, 5, "Natürliche Personen", ln=1)
        self.ln(3)
        self._rule()
        self.ln(4)

    def _rule(self, weight: float = 0.3) -> None:
        self.set_draw_color(*RULE)
        self.set_line_width(weight)
        self.line(18, self.get_y(), 192, self.get_y())

    # -- blocks ------------------------------------------------------------
    def section(self, letter: str, title: str) -> None:
        if self.get_y() > 245:
            self.add_page()
        self.ln(3)
        self.set_font("Helvetica", "B", 10)
        self.set_text_color(*INK)
        self.cell(6, 6, letter)
        self.cell(0, 6, title, ln=1)
        self._rule(0.4)
        self.ln(1.5)

    def line_item(self, ziffer: str, label: str, value: Any, *,
                  note: str = "", bold: bool = False, rule: bool = False) -> None:
        """One numbered row: Ziffer, description, amount in the right column."""
        amount = chf(value)
        if not amount and not bold:
            return
        self.set_font("Helvetica", "B" if bold else "", 9)
        self.set_text_color(*INK)
        self.cell(11, 5.6, ziffer)
        self.cell(101, 5.6, label)
        if note:
            self.set_font("Helvetica", size=7)
            self.set_text_color(*QUIET)
            # Trim by measured width, not character count: cell() does not clip,
            # so an over-long note would print straight through the amount.
            self.cell(32, 5.6, self._fit(note, 31), align="R")
            self.set_font("Helvetica", "B" if bold else "", 9)
            self.set_text_color(*INK)
        else:
            self.cell(32, 5.6, "")
        self.cell(30, 5.6, amount, align="R", ln=1)
        if rule:
            self._rule()
            self.ln(1)

    def _fit(self, text: str, max_mm: float) -> str:
        """Shorten `text` until it fits `max_mm` at the current font."""
        text = self.normalize_text(str(text))
        if self.get_string_width(text) <= max_mm:
            return text
        while text and self.get_string_width(text + "...") > max_mm:
            text = text[:-1]
        return text.rstrip(" ,;") + "..."

    def field_row(self, pairs: list[tuple[str, str]]) -> None:
        """A row of label/value pairs in the taxpayer block."""
        width = 174 / max(1, len(pairs))
        y = self.get_y()
        for i, (label, value) in enumerate(pairs):
            x = 18 + i * width
            self.set_xy(x, y)
            self.set_font("Helvetica", size=7)
            self.set_text_color(*QUIET)
            self.cell(width, 3.6, label, ln=2)
            self.set_font("Helvetica", size=9.5)
            self.set_text_color(*INK)
            self.cell(width, 5, str(value or "—"))
        self.set_xy(18, y + 9.6)


# ── the document ────────────────────────────────────────────────────────────

def build(submission: dict, *, persona: str, tax_year: int,
          score: dict | None = None) -> bytes:
    """Render a filed return. `submission` is the form tree the agent produced."""
    data = submission.get("submission_json", submission)
    pdf = TaxFormPDF(tax_year)
    pdf.add_page()
    pdf.letterhead()

    # ── taxpayer ────────────────────────────────────────────────────────
    main = _get(data, "personal.main") or {}
    partner = _get(data, "personal.partner") or {}
    name = f"{main.get('firstName','')} {main.get('lastName','')}".strip() or persona
    street = f"{main.get('street','')} {main.get('streetNumber','')}".strip()
    town = f"{main.get('zip','')} {main.get('city','')}".strip()

    pdf.section("A", "Personalien")
    pdf.field_row([("Name, Vorname", name), ("AHV-Nummer", main.get("ahvnumber", ""))])
    pdf.field_row([("Adresse", street), ("PLZ / Ort", town)])
    pdf.field_row([
        ("Geburtsdatum", _date(main.get("dateofbirth"))),
        ("Zivilstand", MARITAL.get(str(main.get("maritalstatus", "")).lower(), main.get("maritalstatus", ""))),
        ("Beruf", main.get("occupation", "")),
    ])
    if main.get("employer"):
        pdf.field_row([("Arbeitgeber", main.get("employer", ""))])
    if partner.get("firstName") or partner.get("lastName"):
        pdf.field_row([
            ("Ehepartner/in", f"{partner.get('firstName','')} {partner.get('lastName','')}".strip()),
            ("AHV-Nummer", partner.get("ahvnumber", "")),
            ("Beruf", partner.get("occupation", "")),
        ])
    children = [c for c in (_get(data, "personal.children") or []) if c.get("name")]
    if children:
        pdf.field_row([("Kinder", ", ".join(
            f"{c.get('name','')} ({_date(c.get('dateOfBirth'))})" for c in children))])

    # ── income ──────────────────────────────────────────────────────────
    pdf.section("B", "Einkünfte im In- und Ausland")
    income_lines = [
        ("1",  "Einkünfte aus unselbständiger Erwerbstätigkeit", _get(data, "income.employment.bruttolohn"), ""),
        ("2",  "Einkünfte aus selbständiger Erwerbstätigkeit", _get(data, "income.selfemployment.netincome"), ""),
        ("3",  "AHV/IV-Renten", _get(data, "income.pension.ahvpension"), ""),
        ("4",  "Renten aus beruflicher Vorsorge (BVG)", _get(data, "income.pension.bvgpension"), ""),
        ("5",  "Übrige Renten und Pensionen", _get(data, "income.pension.otherpension"), ""),
        ("6",  "Wertschriftenertrag — Dividenden", _get(data, "income.investment.dividends"), ""),
        ("7",  "Wertschriftenertrag — Zinsen", _get(data, "income.investment.interest"), ""),
        ("8",  "Unterhaltsbeiträge", _get(data, "income.alimony.amount"), ""),
        ("9",  "Eigenmietwert / Mietertrag", _get(data, "income.rental.eigenmietwert"), ""),
        ("10", "Übrige Einkünfte", _get(data, "income.otherincome.amount"),
               str(_get(data, "income.otherincome.description") or "")),
    ]
    total_income = 0.0
    for ziffer, label, value, note in income_lines:
        pdf.line_item(ziffer, label, value, note=note)
        total_income += _num(value) or 0.0
    pdf.ln(0.5)
    pdf.line_item("11", "Total der Einkünfte", total_income, bold=True, rule=True)

    # ── deductions ──────────────────────────────────────────────────────
    pdf.section("C", "Abzüge")
    flat_rate = str(_get(data, "deductions.berufsauslagen.type") or "flat-rate") == "flat-rate"
    effective = sum(_num(r.get("amount")) or 0.0 for r in (_get(data, "deductions.effective") or []))

    deduction_lines = [
        ("12", "Fahrkosten zwischen Wohn- und Arbeitsstätte", _get(data, "deductions.fahrkosten.amount"),
               str(_get(data, "deductions.fahrkosten.description") or "")),
        ("13", "Mehrkosten für Verpflegung", _get(data, "deductions.verpflegung.amount"), ""),
        ("14", "Berufsauslagen — Pauschale" if flat_rate else "Berufsauslagen — effektiv",
               _get(data, "deductions.flatrate.amount") if flat_rate else effective, ""),
        ("15", "Übrige Berufsauslagen", _get(data, "deductions.weitereberufsauslagen.amount"),
               str(_get(data, "deductions.weitereberufsauslagen.description") or "")),
        ("16", "Schuldzinsen", _get(data, "deductions.schuldzinsen.amount"), ""),
        ("17", "Unterhaltsbeiträge und Rentenleistungen", _get(data, "deductions.unterhaltsbeitraege.amount"), ""),
        ("18", "Beiträge Säule 3a", _get(data, "deductions.pillar3a.amount"), ""),
        ("19", "Versicherungsprämien und Sparzinsen", _get(data, "deductions.insurance.amount"), ""),
        ("20", "Kinderbetreuungskosten", _get(data, "deductions.kinderbetreuungskosten.amount"), ""),
        ("21", "Weiterbildungskosten", _get(data, "deductions.weiterbildungskosten.amount"), ""),
        ("22", "Krankheits- und Unfallkosten", _get(data, "deductions.medical.amount"), ""),
        ("23", "Zweiverdienerabzug", _get(data, "deductions.zweiverdienerabzug.amount"), ""),
        ("24", "Zuwendungen an gemeinnützige Institutionen", _get(data, "deductions.donations.amount"),
               str(_get(data, "deductions.donations.recipient") or "")),
        ("25", "Übrige Abzüge", _get(data, "deductions.otherdeductions.amount"),
               str(_get(data, "deductions.otherdeductions.description") or "")),
    ]
    total_deductions = 0.0
    for ziffer, label, value, note in deduction_lines:
        pdf.line_item(ziffer, label, value, note=note)
        total_deductions += _num(value) or 0.0
    pdf.ln(0.5)
    pdf.line_item("26", "Total der Abzüge", total_deductions, bold=True, rule=True)
    pdf.ln(1)
    pdf.line_item("27", "Reineinkommen", total_income - total_deductions, bold=True, rule=True)

    # ── wealth ──────────────────────────────────────────────────────────
    pdf.section("D", "Vermögen im In- und Ausland")
    accounts = _get(data, "wealth.bankaccounts") or []
    securities = _get(data, "wealth.securities") or []
    debts = _get(data, "wealth.debts") or []

    bank_total = sum(_num(a.get("balance")) or 0.0 for a in accounts)
    sec_total = sum(_num(s.get("value")) or _num(s.get("marketValue")) or 0.0 for s in securities)
    debt_total = sum(_num(d.get("amount")) or 0.0 for d in debts)

    for account in accounts:
        if _num(account.get("balance")) is None:
            continue
        pdf.line_item("28", "Bankguthaben", account.get("balance"),
                      note=str(account.get("bankName") or ""))
    if sec_total:
        pdf.line_item("29", "Wertschriften (Steuerwert)", sec_total)
    pdf.line_item("30", "Bewegliches Vermögen", _get(data, "wealth.movable.value"))
    pdf.line_item("31", "Liegenschaften (Steuerwert)", _get(data, "wealth.realestate.steuerwert"))
    for debt in debts:
        if _num(debt.get("amount")) is None:
            continue
        pdf.line_item("32", "Schulden", -(_num(debt.get("amount")) or 0.0),
                      note=str(debt.get("creditor") or ""))
    pdf.ln(0.5)
    net_wealth = bank_total + sec_total + (_num(_get(data, "wealth.movable.value")) or 0.0) \
        + (_num(_get(data, "wealth.realestate.steuerwert")) or 0.0) - debt_total
    pdf.line_item("33", "Reinvermögen", net_wealth, bold=True, rule=True)

    # ── provenance ──────────────────────────────────────────────────────
    pdf.ln(6)
    pdf.set_font("Helvetica", size=7.5)
    pdf.set_text_color(*QUIET)
    filed = datetime.now().strftime("%d.%m.%Y, %H:%M")
    pdf.multi_cell(0, 4,
                   f"Filed by AgenTekki on {filed}. Every value above was read from the taxpayer's "
                   f"documents and entered by an AI agent without human input.")
    if score and score.get("scored") and score.get("score_percent") is not None:
        pdf.ln(1)
        pdf.set_font("Helvetica", "B", 8)
        pdf.set_text_color(*ZURICH)
        pdf.cell(0, 4.5,
                 f"Agent accuracy against the reference return: {score['score_percent']}% "
                 f"({score.get('correct', 0)} of {score.get('total', 0)} values correct)")

    return bytes(pdf.output())
