"""Personas API routes."""

import json
import re
import unicodedata
from datetime import datetime
from pathlib import Path

from flask import Blueprint, Response, jsonify, request

from backend.config import DEMO_PERSONAS_DIR, TAX_YEAR, get_persona_names, is_scored, persona_dir

# Files that exist for scoring or as agent output — never shown as "documents".
_HIDDEN_FILES = {
    "ground_truth.json", "private_notes.json",
    "submitted_return.json", "interaction_log.json",
}

bp = Blueprint("personas", __name__, url_prefix="/api/personas")

# Display metadata for the five exercise taxpayers. Anything created through
# the UI at demo time falls back to its profile.json instead.
_PERSONA_META = {
    "anna_meier": {
        "display_name": "Anna Meier",
        "description": "Single professional, employment income, standard deductions",
        "difficulty": "easy",
        "color": "emerald",
    },
    "marco_laura_bernasconi": {
        "display_name": "Marco & Laura Bernasconi",
        "description": "Married couple, dual income, children, property",
        "difficulty": "hard",
        "color": "rose",
    },
    "priya_chakraborty": {
        "display_name": "Priya Chakraborty",
        "description": "Expat employee, international considerations, pillar 3a",
        "difficulty": "medium",
        "color": "amber",
    },
    "thomas_elisabeth_widmer": {
        "display_name": "Thomas & Elisabeth Widmer",
        "description": "Retired couple, pension income, investment portfolio",
        "difficulty": "medium",
        "color": "sky",
    },
    "yuki_tanaka": {
        "display_name": "Yuki Tanaka",
        "description": "Self-employed freelancer, complex deductions, securities",
        "difficulty": "hard",
        "color": "violet",
    },
}

_CUSTOM_COLORS = ["emerald", "rose", "amber", "sky", "violet", "slate"]
_color_idx = 0


def _get_persona_names() -> list[str]:
    """Exercise personas first, then the demo-only ones."""
    return get_persona_names()


def _load_persona(name: str) -> dict:
    folder = persona_dir(name) or (DEMO_PERSONAS_DIR / name)
    # For custom personas, try to read display info from profile.json
    default_meta = {"display_name": name.replace("_", " ").title(), "description": "", "difficulty": "medium", "color": "slate"}
    meta = _PERSONA_META.get(name, default_meta)

    result = {
        "name": name,
        **meta,
        # Only the five exercise personas ship an answer key; the rest are shown
        # as demo cases and the dashboard says "not scored" instead of a number.
        "scored": is_scored(name),
        # Null until the agent has filed a return for this taxpayer.
        "last_run": _last_run(name),
        "documents": [],
        "profile": {},
    }

    # Document list (exclude scoring and output files)
    if folder.exists():
        docs = [
            f.name for f in sorted(folder.iterdir())
            if f.is_file() and not f.name.startswith(".") and not f.name.startswith("_")
            and f.name not in _HIDDEN_FILES
        ]
        result["documents"] = docs

    # Profile info from profile.json if exists
    profile_path = folder / "profile.json"
    if profile_path.exists():
        try:
            with open(profile_path) as f:
                profile = json.load(f)
                result["profile"] = profile
                # For custom personas, use profile fields for display
                if name not in _PERSONA_META:
                    if profile.get("name"):
                        result["display_name"] = profile["name"]
                    if profile.get("brief"):
                        result["description"] = profile["brief"]
                    if profile.get("_color"):
                        result["color"] = profile["_color"]
        except Exception:
            pass

    return result


def _last_run(name: str) -> dict | None:
    """The result of the most recent agent run for this persona, if there is one.

    ``MCPServer.submit_form()`` saves ``submitted_return.json`` into the persona
    folder, so a completed run survives a browser refresh or an app restart —
    unlike the browser's own record of it. The score is recomputed here rather
    than stored, so it always reflects the current answer key.
    """
    folder = persona_dir(name)
    if folder is None:
        return None
    saved = folder / "submitted_return.json"
    if not saved.exists():
        return None

    result: dict = {
        "completed_at": datetime.fromtimestamp(saved.stat().st_mtime).isoformat(timespec="seconds"),
        "scored": False,
        "score_percent": None,
    }
    try:
        from backend.services.agent_service import _compute_score

        submission = json.loads(saved.read_text(encoding="utf-8"))
        score = _compute_score(name, submission.get("submission_json", submission))
        result["scored"] = bool(score.get("scored"))
        result["score_percent"] = score.get("score_percent")
    except Exception:
        pass  # a completed run with no grade is still worth showing
    return result


def _slugify(text: str) -> str:
    """Convert display name to a filesystem-safe slug."""
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s-]+", "_", text)
    return text or "custom_persona"


@bp.route("/", methods=["GET"])
@bp.route("", methods=["GET"])
def list_personas():
    names = _get_persona_names()
    personas = [_load_persona(name) for name in names]
    return jsonify(personas)


@bp.route("/<name>", methods=["GET"])
def get_persona(name: str):
    names = _get_persona_names()
    if name not in names:
        return jsonify({"error": f"Unknown persona: {name}"}), 404
    return jsonify(_load_persona(name))


def _saved_submission(name: str) -> dict | None:
    folder = persona_dir(name)
    saved = folder / "submitted_return.json" if folder else None
    if saved is None or not saved.exists():
        return None
    return json.loads(saved.read_text(encoding="utf-8"))


@bp.route("/<name>/submission", methods=["GET"])
def get_submission(name: str):
    """The filled return from the most recent run, as raw JSON."""
    submission = _saved_submission(name)
    if submission is None:
        return jsonify({"error": "No completed run for this persona"}), 404
    return jsonify(submission)


@bp.route("/<name>/submission.pdf", methods=["GET"])
def get_submission_pdf(name: str):
    """The same return laid out as the canton's paper form."""
    submission = _saved_submission(name)
    if submission is None:
        return jsonify({"error": "No completed run for this persona"}), 404

    from backend.services.agent_service import _compute_score
    from backend.services.pdf_export import build

    data = submission.get("submission_json", submission)
    score = _compute_score(name, data) if is_scored(name) else None
    pdf = build(submission, persona=name, tax_year=TAX_YEAR, score=score)

    return Response(pdf, mimetype="application/pdf", headers={
        "Content-Disposition": f'attachment; filename="steuererklaerung-{TAX_YEAR}-{name}.pdf"',
        "Content-Length": str(len(pdf)),
    })


@bp.route("", methods=["POST"])
@bp.route("/", methods=["POST"])
def create_persona():
    """Create a new custom persona from multipart form data.

    Expected form fields:
      - name (str, required)
      - address (str)
      - date_of_birth (str)
      - ahv_number (str)
      - marital_status (str)
      - nationality (str)
      - brief (str)

    Expected files:
      - documents (one or more files)
    """
    global _color_idx

    name = request.form.get("name", "").strip()
    if not name:
        return jsonify({"error": "Name is required"}), 400

    # Personas created through the UI are demo cases: they land in the app's own
    # folder, never in the repository's exercise personas.
    slug = _slugify(name)
    folder = DEMO_PERSONAS_DIR / slug

    # Ensure unique folder name
    if folder.exists():
        i = 2
        while (DEMO_PERSONAS_DIR / f"{slug}_{i}").exists():
            i += 1
        slug = f"{slug}_{i}"
        folder = DEMO_PERSONAS_DIR / slug

    folder.mkdir(parents=True, exist_ok=True)

    # Assign a color
    color = _CUSTOM_COLORS[_color_idx % len(_CUSTOM_COLORS)]
    _color_idx += 1

    # Build profile.json
    profile = {
        "name": name,
        "address": request.form.get("address", ""),
        "date_of_birth": request.form.get("date_of_birth", ""),
        "ahv_number": request.form.get("ahv_number", ""),
        "zivilstand": request.form.get("marital_status", ""),
        "nationality": request.form.get("nationality", "CH"),
        "permit": None,
        "brief": request.form.get("brief", ""),
        "_color": color,
    }

    with open(folder / "profile.json", "w") as f:
        json.dump(profile, f, indent=2, ensure_ascii=False)

    # Save uploaded documents
    files = request.files.getlist("documents")
    for file in files:
        if file.filename:
            safe_name = Path(file.filename).name  # strip directory components
            file.save(str(folder / safe_name))

    return jsonify(_load_persona(slug)), 201
