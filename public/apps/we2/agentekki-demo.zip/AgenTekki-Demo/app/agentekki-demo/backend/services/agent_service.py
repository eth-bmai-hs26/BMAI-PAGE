"""
Session management for the Flask backend.

Creates and runs agent sessions backed by FlaskBridge + MCPServer + think().
"""

import json
import logging
import os
import queue
import sys
import threading
import uuid
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

# The app and the repository root both go on the path: the demo imports the
# exercise's mcp_server and scorer directly instead of keeping copies of them.
_APP_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_APP_ROOT))
sys.path.insert(0, str(_APP_ROOT.parent.parent))

from backend.bridges.flask_bridge import FlaskBridge
from backend.config import (
    ANTHROPIC_API_KEY, FIELD_SCHEMA_PATH, GEMINI_API_KEY, GUIDES_DIR,
    LLM_MODEL, LLM_PROVIDER, OLLAMA_BASE_URL, OPENAI_API_KEY, OPENROUTER_API_KEY,
    OPENROUTER_BASE_URL, REPO_ROOT, get_persona_names, is_scored, persona_dir,
)
from backend.services.think_service import think
from mcp_server.server import MCPServer
from mcp_server.ask_user import make_llm_ask_user_with_notes
from mcp_server.llm_service import LLMService

logger = logging.getLogger("agent_service")


# ---------------------------------------------------------------------------
# Session dataclass
# ---------------------------------------------------------------------------

@dataclass
class Session:
    session_id: str
    persona: str
    status: str = "idle"           # idle | running | done | error
    bridge: Optional[FlaskBridge] = None
    server: Optional[MCPServer] = None
    sse_queue: Optional[queue.Queue] = None
    thread: Optional[threading.Thread] = None
    result: Optional[dict] = None
    score: Optional[dict] = None
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# LLM client factory
# ---------------------------------------------------------------------------

def _make_llm() -> LLMService:
    """Build the exercise's LLMService for the configured provider.

    This is the same wrapper the notebook uses (``mcp_server/llm_service.py``),
    so the demo and the exercise talk to the model through identical code.
    """
    if LLM_PROVIDER == "openrouter":
        return LLMService.openai_compatible(
            model=LLM_MODEL, base_url=OPENROUTER_BASE_URL, api_key=OPENROUTER_API_KEY,
        )
    if LLM_PROVIDER == "ollama":
        # Ollama defaults to a 4096-token context, and this agent's execute-phase
        # prompts reach ~4,400 tokens once documents and a guide are attached —
        # so without this the oldest part of the prompt is silently dropped and
        # the agent never sees the documents it asked for. Raise it, but not
        # wildly: the KV cache costs memory on top of the model weights, and the
        # usual machine here has 16 GB. Override with OLLAMA_NUM_CTX if needed.
        num_ctx = int(os.environ.get("OLLAMA_NUM_CTX", "8192"))
        llm = LLMService.ollama(model=LLM_MODEL, host=OLLAMA_BASE_URL.rsplit("/v1", 1)[0])
        llm.extra_body = {"options": {"num_ctx": num_ctx}}
        return llm
    if LLM_PROVIDER == "gemini":
        return LLMService.openai_compatible(
            model=LLM_MODEL,
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
            api_key=GEMINI_API_KEY,
        )
    if LLM_PROVIDER == "openai":
        return LLMService.openai_compatible(
            model=LLM_MODEL, base_url="https://api.openai.com/v1", api_key=OPENAI_API_KEY,
        )
    return LLMService.openai_compatible(
        model=LLM_MODEL, base_url="https://api.anthropic.com/v1/", api_key=ANTHROPIC_API_KEY,
    )


def _make_llm_client():
    """The raw OpenAI-compatible client, for the simulated taxpayer (NPC)."""
    return _make_llm()._client


# ---------------------------------------------------------------------------
# In-memory store
# ---------------------------------------------------------------------------

_sessions: dict[str, Session] = {}
_sessions_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def create_session(persona: str) -> Session:
    """Create a new session for the given persona."""
    folder = persona_dir(persona)
    if folder is None:
        raise ValueError(f"Unknown persona: {persona!r}. Choose from {get_persona_names()}")

    persona_folder = str(folder)
    sse_q: queue.Queue = queue.Queue()

    bridge = FlaskBridge(sse_queue=sse_q)

    # NPC function — uses same provider as main LLM
    try:
        npc_client = _make_llm_client()
        ask_user_fn = make_llm_ask_user_with_notes(
            persona_folder=persona_folder,
            model=LLM_MODEL,
            client=npc_client,
        )
    except Exception:
        # Fallback: rule-based NPC
        ask_user_fn = None

    server = MCPServer(
        persona_folder=persona_folder,
        bridge=bridge,
        ask_user_fn=ask_user_fn,
    )

    session = Session(
        session_id=str(uuid.uuid4()),
        persona=persona,
        status="idle",
        bridge=bridge,
        server=server,
        sse_queue=sse_q,
    )

    with _sessions_lock:
        _sessions[session.session_id] = session

    return session


def get_session(session_id: str) -> Optional[Session]:
    with _sessions_lock:
        return _sessions.get(session_id)


def list_sessions() -> list[Session]:
    with _sessions_lock:
        return list(_sessions.values())


def delete_session(session_id: str) -> bool:
    with _sessions_lock:
        if session_id in _sessions:
            del _sessions[session_id]
            return True
    return False


def run_session(session_id: str) -> None:
    """Start the agent in a background thread."""
    session = get_session(session_id)
    if session is None:
        raise KeyError(f"Session {session_id!r} not found")
    if session.status == "running":
        return  # already running

    session.status = "running"

    def _worker():
        try:
            persona_folder = str(persona_dir(session.persona))
            result = think(
                server=session.server,
                persona_folder=persona_folder,
                llm=_make_llm(),
                guides_dir=GUIDES_DIR if GUIDES_DIR.exists() else None,
                sse_queue=session.sse_queue,
            )
            session.result = result
            submission = result.get("submission", {})
            submission_json = submission.get("submission_json", {}) if isinstance(submission, dict) else {}
            session.score = _compute_score(session.persona, submission_json)
            session.status = "done"
            score_pct = session.score.get("score_percent") if session.score else None
            _emit(session, {"type": "agent_done", "score_percent": score_pct})
        except Exception as exc:
            session.status = "error"
            session.error = str(exc)
            _emit(session, {"type": "agent_error", "error": str(exc)})

    t = threading.Thread(target=_worker, daemon=True)
    session.thread = t
    t.start()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _emit(session: Session, event: dict) -> None:
    if session.sse_queue is not None:
        try:
            session.sse_queue.put_nowait(event)
        except Exception:
            pass


def _compute_score(persona: str, submission_json: dict) -> dict:
    """Score a submission with the exercise's own scorer (scripts/eval_lib.py).

    Students are graded by this code, so the number on the dashboard is the
    number they would get. Personas without a ground_truth.json are not scored.
    """
    if not is_scored(persona):
        return {"scored": False, "score_percent": None,
                "reason": "No ground_truth.json — this persona is a demo case, not an exercise case."}

    try:
        from scripts.eval_lib import load_schema, score as eval_score

        folder = persona_dir(persona)
        ground_truth = json.loads((folder / "ground_truth.json").read_text(encoding="utf-8"))
        schema = load_schema(FIELD_SCHEMA_PATH)

        report = eval_score(ground_truth, submission_json, schema, persona=persona)

        return {
            "scored": True,
            "score_percent": round(report.score, 1),
            "raw_score_percent": round(report.raw_score, 1),
            "correct": report.correct,
            "wrong": report.wrong,
            "missing": report.missing,
            "extra": report.extra,
            "total": report.total,
            "problems": [
                {"path": r.path, "type": r.type, "verdict": r.verdict,
                 "tier": r.tier, "expected": r.gt, "got": r.sub, "detail": r.detail}
                for r in report.problems()
            ],
        }
    except Exception as exc:
        logger.exception("Scoring failed for %s", persona)
        return {"scored": False, "error": str(exc), "score_percent": None}
