"""Flask backend configuration — reads from environment variables.

The demo deliberately owns no copy of the exercise material. Personas, guides,
the MCP server and the scorer are all read from the repository root, so the demo
students watch can never drift from the exercise they are graded on.
"""

import json
import os
from pathlib import Path

# backend/config.py -> backend/ -> the app -> app/ -> repo root
APP_ROOT = Path(__file__).resolve().parent.parent
REPO_ROOT = APP_ROOT.parent.parent

# Shared with the exercise — single source of truth, never copied into the app.
PERSONAS_DIR = REPO_ROOT / "personas"
GUIDES_DIR = REPO_ROOT / "guides"
SCRIPTS_DIR = REPO_ROOT / "scripts"
FIELD_SCHEMA_PATH = PERSONAS_DIR / "field_schema.json"

# Demo-only personas. These have no ground_truth.json, so they are shown but
# not scored; they exist to make the dashboard look like a real caseload.
DEMO_PERSONAS_DIR = APP_ROOT / "personas_demo"

def _saved() -> dict:
    """What the first-run wizard stored, if it has been through."""
    try:
        return json.loads((APP_ROOT / ".agentekki" / "config.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


_CONFIG = _saved()


def _setting(env_var: str, key: str, default: str = "") -> str:
    """Environment variable first, then the wizard's saved choice, then default."""
    return os.environ.get(env_var) or _CONFIG.get(key) or default


# The tax year shown on the form and the generated PDF. Keep in step with
# frontend/src/taxYear.ts, which carries the same number for the UI, and with
# the dates in the persona documents.
TAX_YEAR = int(os.environ.get("AGENTEKKI_TAX_YEAR", "2026"))

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
OPENROUTER_API_KEY = _setting("OPENROUTER_API_KEY", "openrouter_api_key")

# LLM_PROVIDER: "openrouter" | "ollama" | "gemini" | "openai" | "anthropic".
# The notebook students use runs on OpenRouter, so that is the default here too.
LLM_PROVIDER = _setting("LLM_PROVIDER", "provider", "openrouter")

# Model defaults per provider
_DEFAULT_MODELS = {
    "openrouter": "anthropic/claude-sonnet-4.5",
    "gemini": "gemini-2.5-flash",
    "openai": "gpt-4o-mini",
    "anthropic": "claude-sonnet-4-5",
    "ollama": "gemma3:12b",
}
LLM_MODEL = _setting("LLM_MODEL", "model") or _DEFAULT_MODELS.get(LLM_PROVIDER, "anthropic/claude-sonnet-4.5")

# Endpoints
OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1")
OPENROUTER_BASE_URL = os.environ.get("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")


def persona_dir(name: str) -> Path | None:
    """Resolve a persona name to its folder, exercise personas first."""
    for base in (PERSONAS_DIR, DEMO_PERSONAS_DIR):
        candidate = base / name
        if (candidate / "profile.json").exists():
            return candidate
    return None


def get_persona_names() -> list[str]:
    """Every persona folder containing a profile.json, exercise ones first."""
    names: list[str] = []
    for base in (PERSONAS_DIR, DEMO_PERSONAS_DIR):
        if not base.exists():
            continue
        names += [
            d.name for d in sorted(base.iterdir())
            if d.is_dir() and (d / "profile.json").exists() and d.name not in names
        ]
    return names


def is_scored(name: str) -> bool:
    """A persona can only be scored if it ships a ground_truth.json answer key."""
    folder = persona_dir(name)
    return bool(folder and (folder / "ground_truth.json").exists())
