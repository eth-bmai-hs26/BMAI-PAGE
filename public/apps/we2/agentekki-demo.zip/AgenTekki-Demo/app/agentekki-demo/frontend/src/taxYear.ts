/**
 * The tax year this simulator is filing for, in one place.
 *
 * Note this is the *tax year*, not the current date: in Switzerland you file
 * the previous year's return. It is shown in the header, the overview, the
 * login screen and the downloaded filename, so change it here only.
 *
 * Keep it in step with the persona documents — their salary certificates and
 * bank statements are dated, and a mismatch is the kind of thing a sharp
 * participant spots straight away.
 */
export const TAX_YEAR = 2026;
