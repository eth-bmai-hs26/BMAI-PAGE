import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { listPersonas, getSubmission, submissionPdfUrl, type PersonaInfo } from '../api/client';
import { useSession } from '../context/SessionContext';
import zurichArms from '../assets/ZurichLogo.png';
import { TAX_YEAR } from '../taxYear';

/* Flat, not gradients: the colour is an identity tag for a taxpayer, so it
   should read as a flat index marker rather than decoration. */
const ACCENT_COLORS: Record<string, string> = {
  emerald: '#0E7A3D',
  rose:    '#C2185B',
  amber:   '#A65F00',
  sky:     '#0369A1',
  violet:  '#6D28D9',
  slate:   '#475569',
};

interface CompletedPersona {
  persona: string;
  displayName: string;
  score: number | null;
  date: string;
  formData?: Record<string, unknown>;
}

function getCompleted(): CompletedPersona[] {
  try {
    return JSON.parse(localStorage.getItem('completedPersonas') || '[]');
  } catch { return []; }
}

/** A counted figure in the letterhead. Tabular so the two line up. */
function Tally({ value, label, tone }: { value: number; label: string; tone?: string }) {
  return (
    <div style={{ textAlign: 'right' }}>
      <div style={{
        fontSize: '1.75rem', fontWeight: 600, lineHeight: 1,
        fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.03em',
        color: value === 0 ? 'var(--faint)' : (tone ?? 'var(--ink)'),
      }}>
        {value}
      </div>
      <div style={{ fontSize: '0.75rem', color: 'var(--quiet)', marginTop: '5px' }}>
        {label}
      </div>
    </div>
  );
}

function PersonaRow({ persona, loading, onClick }: {
  persona: PersonaInfo;
  loading: boolean;
  onClick: () => void;
}) {
  const accent = ACCENT_COLORS[persona.color] ?? ACCENT_COLORS.slate;
  const initials = persona.display_name
    .split(' ')
    .map(w => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <button
      onClick={onClick}
      disabled={loading}
      className="register-row"
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        width: '100%',
        background: 'transparent',
        border: 'none',
        borderRadius: 0,
        padding: '15px 22px',
        cursor: loading ? 'wait' : 'pointer',
        textAlign: 'left',
        font: 'inherit',
        opacity: loading ? 0.6 : 1,
      }}
    >
      {/* Identity tag. The letter block indexes the taxpayer; it is the only
          colour in the row. */}
      <div style={{
        width: '34px', height: '34px', borderRadius: '5px', background: accent,
        display: 'grid', placeItems: 'center', color: '#fff',
        fontSize: '0.75rem', fontWeight: 600, letterSpacing: '0.01em', flexShrink: 0,
      }}>
        {initials}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: '0.9375rem', fontWeight: 600, color: 'var(--ink)',
          letterSpacing: '-0.012em', lineHeight: 1.35,
        }}>
          {persona.display_name}
        </div>
        <div style={{
          fontSize: '0.8125rem', color: 'var(--quiet)', lineHeight: 1.4,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          {persona.description}
        </div>
      </div>

      <div style={{
        fontSize: '0.8125rem', color: 'var(--faint)', flexShrink: 0,
        fontVariantNumeric: 'tabular-nums', width: '84px', textAlign: 'right',
      }}>
        {persona.documents.length} documents
      </div>

      {/* Only the exercise taxpayers ship an answer key; state it plainly
          rather than as a shouted chip. */}
      <div style={{
        fontSize: '0.8125rem', flexShrink: 0, width: '96px', textAlign: 'right',
        color: persona.scored === false ? 'var(--faint)' : 'transparent',
      }}>
        {persona.scored === false ? 'no answer key' : '—'}
      </div>

      <span className="row-action" style={{
        fontSize: '0.8125rem', fontWeight: 500, flexShrink: 0,
        border: '1px solid var(--rule)', borderRadius: 'var(--radius)',
        padding: '6px 15px', color: 'var(--zurich)', background: 'var(--sheet)',
        display: 'inline-flex', alignItems: 'center', gap: '7px',
        transition: 'background .14s, border-color .14s, color .14s',
      }}>
        {loading && (
          <span style={{
            width: '12px', height: '12px', borderRadius: '50%',
            border: '2px solid var(--rule)', borderTopColor: 'var(--zurich)',
            animation: 'spin 0.8s linear infinite',
          }} />
        )}
        {loading ? 'Starting' : 'Start'}
      </span>
    </button>
  );
}

function CompletedRow({ item }: { item: CompletedPersona }) {
  const handleDownload = async () => {
    // Prefer what this browser saved; otherwise ask the server, which keeps the
    // filed return on disk. Without the fallback the button would do nothing
    // for a run recorded in a different browser or before a restart.
    let data = item.formData;
    if (!data) {
      try {
        data = await getSubmission(item.persona);
      } catch {
        return;
      }
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zh-tax-filing-${item.persona}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const score = item.score;
  const scoreColor = score == null ? 'var(--faint)'
    : score >= 80 ? 'var(--filed)' : score >= 50 ? 'var(--amber)' : 'var(--flag)';

  return (
    <div className="register-row" style={{
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
      width: '100%',
      padding: '15px 22px',
    }}>
      {/* Name */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: '0.9375rem', fontWeight: 600, color: 'var(--ink)', letterSpacing: '-0.012em' }}>
          {item.displayName}
        </div>
        <div style={{ fontSize: '0.8125rem', color: 'var(--quiet)' }}>
          Filed {item.date}
        </div>
      </div>

      {/* The grade, as a figure with the accuracy drawn underneath it. */}
      <div style={{ flexShrink: 0, width: '108px', textAlign: 'right' }}>
        {score != null ? (
          <>
            <div style={{
              fontSize: '1.125rem', fontWeight: 600, color: scoreColor,
              fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.02em', lineHeight: 1.1,
            }}>
              {score}%
            </div>
            <div style={{
              height: '3px', background: 'var(--rule-soft)', borderRadius: '2px',
              marginTop: '6px', overflow: 'hidden',
            }}>
              <div style={{ width: `${Math.max(0, Math.min(100, score))}%`, height: '100%', background: scoreColor }} />
            </div>
          </>
        ) : (
          <span style={{ fontSize: '0.8125rem', color: 'var(--faint)' }}>no answer key</span>
        )}
      </div>

      {/* Two ways out: the completed form as the canton's paper return, or the
          raw values the agent produced. */}
      <div style={{ display: 'flex', gap: '8px', flexShrink: 0 }}>
        <a
          href={submissionPdfUrl(item.persona)}
          download
          className="row-action-btn"
          style={{
            background: 'var(--sheet)', border: '1px solid var(--rule)',
            borderRadius: 'var(--radius)', padding: '6px 15px',
            fontSize: '0.8125rem', fontWeight: 500, color: 'var(--ink-soft)',
            textDecoration: 'none', transition: 'border-color .14s, background .14s',
          }}
        >
          Tax form (PDF)
        </a>
        <button
          onClick={handleDownload}
          className="row-action-btn"
          style={{
            background: 'var(--sheet)', border: '1px solid var(--rule)',
            borderRadius: 'var(--radius)', padding: '6px 15px',
            fontSize: '0.8125rem', fontWeight: 500, color: 'var(--ink-soft)',
            cursor: 'pointer', transition: 'border-color .14s, background .14s',
          }}
        >
          JSON
        </button>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [personas, setPersonas] = useState<PersonaInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState<string | null>(null);
  const [completed, setCompleted] = useState<CompletedPersona[]>(getCompleted);
  const { startSession } = useSession();
  const navigate = useNavigate();

  useEffect(() => {
    listPersonas()
      .then(list => {
        setPersonas(list);
        // The server is the source of truth for completed runs: it still has
        // the filed return on disk and rescores it on request, so a grade
        // survives a browser refresh, a different browser, or an app restart.
        // The browser's own record only supplies the saved form data for
        // Download, and covers anything the server no longer knows about.
        const local = getCompleted();
        const fromServer: CompletedPersona[] = list
          .filter(p => p.last_run)
          .map(p => ({
            persona: p.name,
            displayName: p.display_name,
            score: p.last_run!.score_percent ?? null,
            date: new Date(p.last_run!.completed_at).toLocaleDateString('en-US',
              { month: 'short', day: 'numeric' }),
            formData: local.find(c => c.persona === p.name)?.formData,
          }));
        const known = new Set(fromServer.map(c => c.persona));
        setCompleted([...fromServer, ...local.filter(c => !known.has(c.persona))]);
      })
      .catch(e => setError(String(e)))
      .finally(() => setLoading(false));
  }, []);

  const completedNames = new Set(completed.map(c => c.persona));
  const pending = personas.filter(p => !completedNames.has(p.name));

  const handleSelect = async (persona: PersonaInfo) => {
    setStarting(persona.name);
    try {
      await startSession(persona.name);
      navigate('/personal');
    } catch (e) {
      setError(String(e));
      setStarting(null);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--paper)' }}>
      {/* Letterhead — the top of an actual cantonal return, not a marketing hero.
          The tax year is the one loud element on the page. */}
      <div style={{ background: 'var(--sheet)', borderBottom: '1px solid var(--rule)' }}>
        <div style={{
          maxWidth: '980px', margin: '0 auto', padding: '40px 32px 30px',
          display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
          gap: '32px', flexWrap: 'wrap',
        }}>
          <div>
            <div style={{
              fontSize: '0.8125rem', color: 'var(--quiet)', marginBottom: '10px',
              display: 'flex', alignItems: 'center', gap: '9px',
            }}>
              <img src={zurichArms} alt="" style={{ display: 'block', height: '20px', width: 'auto', flexShrink: 0 }} />
              Kantonales Steueramt Zürich
            </div>
            <h1 style={{
              fontSize: 'clamp(2rem, 5vw, 2.9rem)', fontWeight: 700, margin: 0,
              letterSpacing: '-0.035em', lineHeight: 1, color: 'var(--ink)',
            }}>
              Steuererklärung{' '}
              <span style={{ fontVariantNumeric: 'tabular-nums', color: 'var(--zurich)' }}>
                {TAX_YEAR}
              </span>
            </h1>
            <p style={{ fontSize: '0.9375rem', color: 'var(--quiet)', margin: '10px 0 0' }}>
              Private tax returns, filed by an AI agent
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'flex-end', gap: '30px' }}>
            <Tally value={pending.length} label={pending.length === 1 ? 'to file' : 'to file'} />
            <Tally value={completed.length} label="filed" tone="var(--filed)" />
            <button
              onClick={() => navigate('/create-persona')}
              style={{
                background: 'var(--sheet)', border: '1px solid var(--rule)',
                color: 'var(--ink)', padding: '9px 16px', borderRadius: 'var(--radius)',
                fontSize: '0.875rem', fontWeight: 500, cursor: 'pointer',
                transition: 'border-color .15s, background .15s',
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--zurich)'; e.currentTarget.style.background = 'var(--zurich-wash)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--rule)'; e.currentTarget.style.background = 'var(--sheet)'; }}
            >
              Add a taxpayer
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{
        maxWidth: '980px',
        margin: '0 auto',
        padding: '32px 32px 72px',
        position: 'relative',
        zIndex: 1,
      }}>
        {loading && (
          <div style={{
            background: '#fff',
            borderRadius: '16px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
            padding: '48px',
            textAlign: 'center',
            color: '#64748b',
            fontSize: '0.9375rem',
          }}>
            <div style={{
              width: '32px', height: '32px',
              border: '3px solid #e2e8f0', borderTopColor: '#1e40af',
              borderRadius: '50%', animation: 'spin 0.8s linear infinite',
              margin: '0 auto 16px',
            }} />
            Loading personas…
          </div>
        )}

        {error && (
          <div style={{
            background: '#fef2f2',
            border: '1px solid #fecaca',
            borderRadius: '12px',
            padding: '20px 24px',
            color: '#dc2626',
            fontSize: '0.875rem',
            marginBottom: '24px',
          }}>
            <strong>Could not connect to backend:</strong> {error}
            <div style={{ marginTop: '8px', color: '#64748b', fontSize: '0.8125rem' }}>
              Make sure Flask is running: <code style={{ background: '#f1f5f9', padding: '2px 6px', borderRadius: '4px' }}>python -m backend.app</code>
            </div>
          </div>
        )}

        {!loading && !error && (
          <>
            {/* Awaiting filing */}
            <section style={{ marginBottom: '36px' }}>
              <h2 style={{
                fontSize: '0.9375rem', fontWeight: 600, color: 'var(--ink)',
                margin: '0 0 12px', letterSpacing: '-0.012em',
              }}>
                Awaiting filing
              </h2>

              {pending.length === 0 ? (
                <div className="sheet" style={{ padding: '30px 22px', color: 'var(--quiet)', fontSize: '0.9375rem' }}>
                  Every taxpayer has been filed. Add another to keep going.
                </div>
              ) : (
                <div className="sheet">
                  {pending.map(p => (
                    <PersonaRow
                      key={p.name}
                      persona={p}
                      loading={starting === p.name}
                      onClick={() => handleSelect(p)}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* Filed */}
            <section>
              <h2 style={{
                fontSize: '0.9375rem', fontWeight: 600, color: 'var(--ink)',
                margin: '0 0 12px', letterSpacing: '-0.012em',
              }}>
                Filed
              </h2>
              {completed.length === 0 ? (
                <div className="sheet" style={{ padding: '30px 22px', color: 'var(--quiet)', fontSize: '0.9375rem' }}>
                  Nothing filed yet. Start a taxpayer above and the agent's return will appear here with its score.
                </div>
              ) : (
                <div className="sheet">
                  {completed.map(c => (
                    <CompletedRow key={c.persona} item={c} />
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
