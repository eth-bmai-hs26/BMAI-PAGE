# AgenTekki — the demo app

This is the finished product students are working towards: a web app where you
pick a taxpayer, press start, and watch an AI agent read the documents and fill
a Zurich tax return page by page, ending with a score.

The exercise (the Colab notebook at the repository root) is the *inside* of this
app. Students build the agent — the plan-then-execute reasoning loop — and
nothing else. The frontend and backend here exist so they can see what that
agent looks like once it is wired into a real product.

> **This app owns no copy of the exercise material.** Personas, guides, the MCP
> server and the scorer are all read from the repository root, so what the demo
> shows can never drift from what students build and are graded on. See
> `backend/config.py`.

---

## Run it

**Double-click the launcher.** That is the whole instruction.

| Your computer | Double-click |
|---|---|
| macOS, Linux | `AgenTekki.command` |
| Windows | `AgenTekki.bat` |

A setup wizard opens in your browser and walks through three screens:

1. **System** — confirms what you are running on.
2. **Setup** — installs everything, with a progress bar. Once, then never again.
3. **Model** — either paste an OpenRouter API key, or pick a model to run
   locally on your own machine.

Then it starts the app and takes you to it. On later runs it remembers your
choice and skips straight to the app.

Nothing needs to be installed first. If the launcher cannot find a suitable
Python it downloads a private copy into this folder — nothing is installed
system-wide, and deleting the folder removes every trace. Node.js is never
needed: the interface ships pre-built in `frontend/dist`.

> **macOS may refuse the first double-click** ("cannot be opened because it is
> from an unidentified developer"). Right-click the file → **Open** → **Open**.
> You only do this once.

### Starting over

```bash
./AgenTekki.command --reset     # forget the saved model choice, show the wizard
./AgenTekki.command --wizard    # show the wizard without forgetting anything
```

### Choosing a model

The wizard covers this, but the two routes are:

**An API key (recommended for a demo).** OpenRouter, the same route the student
notebook uses — so a demo run and a student run are comparable. Get a key at
[openrouter.ai/keys](https://openrouter.ai/keys). It is stored in
`.agentekki/config.json` in this folder and nowhere else.

**Locally, with Ollama.** No key, no internet, but slower and less accurate.
The wizard lists models with their download size, memory needed and expected
accuracy, greys out any your machine cannot hold, and marks the ones you have
already. `gemma3:12b` is the best local option if you have 16 GB.

### Running it by hand

For development, the usual two-process setup still works:

```bash
source .venv/bin/activate
export OPENROUTER_API_KEY=sk-or-...
bash start.sh                    # Flask on :5001, Vite dev server on :5173
```

Any provider works through the same OpenAI-compatible wrapper
(`mcp_server/llm_service.py`), selected with `LLM_PROVIDER`:

| `LLM_PROVIDER` | Default model | Needs |
|---|---|---|
| `openrouter` (default) | `anthropic/claude-sonnet-4.5` | `OPENROUTER_API_KEY` |
| `ollama` | `gemma3:12b` | Ollama running locally, no key |
| `gemini` | `gemini-2.5-flash` | `GEMINI_API_KEY` |
| `openai` | `gpt-4o-mini` | `OPENAI_API_KEY` |
| `anthropic` | `claude-sonnet-4-5` | `ANTHROPIC_API_KEY` |

Environment variables win over whatever the wizard saved.

---

## What the demo shows

1. **Dashboard** — every taxpayer as a pending case, with document counts.
2. **The agent working** — the form fills in live, page by page, while a status
   bar reports what the agent is doing. You cannot skip ahead of it.
3. **The taxpayer answering** — when the agent calls `ask_user`, a chat popup
   shows the question and the simulated taxpayer's reply.
4. **The score** — the completed return is graded against the hidden answer key
   with the exercise's own scorer.

### The agent is the exercise's agent

`backend/services/think_service.py` is the same **plan → retrieve → execute**
loop from notebook sections 5–6:

```
Plan       the model sees field labels + document and guide NAMES  ──▶  a plan
Retrieve   only the documents and guides the plan asked for are read
Execute    the model sees its plan + that content  ──▶  {locator: value}
```

The prompts are not a second copy: `backend/services/exercise_prompts.py` holds the
same instructions the exercise notebook sends the model, so the demo and the
notebook always behave the same way.

The only thing the demo adds on top is the `ask_user` popup exchange and the SSE
stream that lets the browser follow along.

### The Berufsauslagen-Pauschale is deliberately not computed for the agent

`deductions.flatrate.amount` is a plain, empty number field — exactly as in
`EnvDemoV1`. Deriving it (3 % of Lohnausweis field 12, clamped to
[2 000, 4 000], per person, summed for joint filers) is *the* tax rule the
exercise teaches. If the form filled it in automatically, the demo would hide
the problem students spend the session solving. See
`docs/decisions/berufsauslagen.md`.

---

## Personas

The five taxpayers from the exercise, read straight from `personas/` at the
repository root — the same files, not copies, so the demo cannot drift from
what students are graded on. Each ships a hidden `ground_truth.json`, so every
run gets a real score:

| Persona | Scenario | Difficulty |
|---|---|---|
| Anna Meier | Single professional, employment income, standard deductions | Easy |
| Priya Chakraborty | Expat employee, international considerations, Pillar 3a | Medium |
| Thomas & Elisabeth Widmer | Retired couple, pension income, investment portfolio | Medium |
| Marco & Laura Bernasconi | Married couple, dual income, children, property | Hard |
| Yuki Tanaka | Self-employed freelancer, complex deductions, securities | Hard |

### Creating a persona live

**Add a taxpayer** on the dashboard writes a new folder into `personas_demo/`
in this app — never into the repository's exercise personas. A taxpayer created
this way has no answer key, so the dashboard marks the run "no answer key"
rather than showing a score.

---

## Scoring

The dashboard score comes from `scripts/eval_lib.py` — the same scorer that
grades students, run through `personas/field_schema.json`. Numbers match within
1 CHF, enums go through the alias table, free text falls back to fuzzy matching,
and fields the agent filled that the answer key leaves empty cost half a point
each.

To score outside the app, use the repository's CLI:

```bash
python scripts/score.py anna_meier path/to/submission.json
python scripts/score.py --all path/to/agent_output_dir/
```

---

## Layout

```
app/agentekki-demo/
├── AgenTekki.command            double-click to start (macOS/Linux)
├── AgenTekki.bat                double-click to start (Windows)
├── launcher/                    first-run wizard — standard library only,
│   ├── bootstrap.py             because it runs before anything is installed
│   ├── setup.py                 environment probing + the setup steps
│   ├── catalog.py               which models to offer, and what to say about them
│   └── wizard.html              the three-screen UI (no build step)
├── backend/                     Flask API
│   ├── app.py                   app factory, CORS, blueprints
│   ├── config.py                paths into the repo root + LLM provider config
│   ├── routes/
│   │   ├── personas.py          GET/POST /api/personas
│   │   └── agent_routes.py      session create / run / SSE stream / score
│   ├── services/
│   │   ├── agent_service.py     sessions, LLM wiring, scoring via eval_lib
│   │   ├── think_service.py     the plan-then-execute agent loop
│   │   └── exercise_prompts.py  GENERATED from the notebook — do not edit
│   └── bridges/
│       ├── flask_bridge.py      server-side form state
│       └── form_model.py        the form's field tree and locators
├── frontend/                    React 19 + TypeScript + Vite
│   └── src/{pages,components,context,api,hooks}
│   └── dist/                    COMMITTED — the built UI, served by Flask so
│                                participants never need Node.js
├── personas_demo/               taxpayers added through the UI (no answer key)
├── start.sh                     two-process dev launch (Flask + Vite)
└── README.md
```

After changing anything under `frontend/src/`, rebuild so the shipped interface
keeps up:

```bash
cd frontend && npm run build
```

Everything else the demo needs — `mcp_server/`, `personas/`, `guides/`,
`scripts/eval_lib.py` — lives at the repository root and is shared with the
exercise.

## Standalone MCP server

The 9 tools can also be driven from Claude Code, Cursor or any MCP client. That
lives at the repository root, not here:

```bash
cd ../..                         # repository root
pip install mcp
python -m mcp_server --persona personas/anna_meier --bridge mock --verbose
```
