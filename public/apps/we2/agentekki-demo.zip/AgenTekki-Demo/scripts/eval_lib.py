"""
eval_lib.py — the single scorer for the agentic tax-filler exercise.

Used by scripts/score.py (CLI), scripts/eval_regress.py (all personas) and the
notebook scoring cell (display only). Design decisions (Phase 2.1):

  * every field has a declared type in personas/field_schema.json, so the
    comparator is chosen deterministically, never guessed from the value;
  * number   -> |Δ| < 1 CHF; plus 0.5 % relative tolerance for fields listed as
               `estimate` for the persona; GT "0" vs empty submission counts as correct
    enum/bool-> alias table (single↔ledig, married↔verheiratet, child↔Kind, ja↔yes …)
    date     -> parsed and compared as dates (ISO, DD.MM.YYYY, DD/MM/YYYY)
    id       -> case/diacritic/punctuation-insensitive exact
    free_text-> exact -> normalised -> rapidfuzz token-set ≥ 0.75 -> optional LLM judge
  * fields the agent filled where the ground truth is empty/absent are reported
    as EXTRA and cost half a point each (headline score cannot be gamed by
    filling everything);
  * the LLM judge is only ever consulted for free_text fields, only when fuzzy
    < 0.75, and its verdicts are cached by (field, sub, gt) hash;
  * every FieldResult records the tier that decided it, so a TA can see WHY.

Public API
    load_schema(path=None) -> dict
    score(gt, sub, schema=None, judge=None, persona=None) -> Report
    extract_submission_data(agent_result) -> dict
    make_judge(llm_call, cache_path=None) -> judge callable
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass, field, asdict
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Callable, Optional

from rapidfuzz import fuzz

REPO = Path(__file__).resolve().parents[1]
DEFAULT_SCHEMA_PATH = REPO / "personas" / "field_schema.json"

FUZZY_THRESHOLD = 0.75
ABS_TOLERANCE = Decimal("1")        # |Δ| < 1 CHF
REL_TOLERANCE = Decimal("0.005")    # 0.5 % for `estimate` fields
EXTRA_PENALTY = 0.5

ENUM_ALIASES = {
    # marital status
    "ledig": "single", "unverheiratet": "single", "single": "single",
    "verheiratet": "married", "married": "married",
    "geschieden": "divorced", "divorced": "divorced",
    "verwitwet": "widowed", "widowed": "widowed",
    "getrennt": "separated", "separated": "separated",
    "eingetragene partnerschaft": "registered_partnership", "registered partnership": "registered_partnership",
    # relationship
    "child": "child", "kind": "child", "tochter": "child", "sohn": "child", "daughter": "child", "son": "child",
    # berufsauslagen mode
    "flat-rate": "flat-rate", "flatrate": "flat-rate", "pauschale": "flat-rate", "pauschal": "flat-rate",
    "effective": "effective", "effektiv": "effective", "itemized": "effective",
}
BOOL_ALIASES = {
    "true": True, "yes": True, "ja": True, "1": True, "on": True, "checked": True,
    "false": False, "no": False, "nein": False, "0": False, "off": False, "": False,
}
DATE_FORMATS = (
    re.compile(r"^(?P<y>\d{4})-(?P<m>\d{1,2})-(?P<d>\d{1,2})$"),
    re.compile(r"^(?P<d>\d{1,2})\.(?P<m>\d{1,2})\.(?P<y>\d{4})$"),
    re.compile(r"^(?P<d>\d{1,2})/(?P<m>\d{1,2})/(?P<y>\d{4})$"),
    re.compile(r"^(?P<y>\d{4})/(?P<m>\d{1,2})/(?P<d>\d{1,2})$"),
)


# ── data classes ────────────────────────────────────────────────────────────
@dataclass
class FieldResult:
    path: str
    type: str
    verdict: str            # correct | wrong | missing | extra
    tier: str               # what decided it, e.g. "number:abs", "enum:alias", "text:fuzzy(0.83)", "text:judge:no"
    gt: Any
    sub: Any
    detail: str = ""


@dataclass
class Report:
    persona: Optional[str]
    correct: int = 0
    wrong: int = 0
    missing: int = 0
    extra: int = 0
    total: int = 0
    raw_score: float = 0.0      # correct / total * 100
    score: float = 0.0          # (correct - 0.5 * extra) / total * 100, floored at 0
    rows: list[FieldResult] = field(default_factory=list)
    untyped: list[str] = field(default_factory=list)   # paths without a schema type (fell back to free_text)

    def problems(self) -> list[FieldResult]:
        return [r for r in self.rows if r.verdict != "correct"]

    def to_dict(self) -> dict:
        d = asdict(self)
        return d


# ── normalisation helpers ───────────────────────────────────────────────────
def is_empty(v: Any) -> bool:
    if v is None:
        return True
    if isinstance(v, bool):
        return False
    if isinstance(v, str):
        return v.strip() == ""
    if isinstance(v, (list, dict)):
        return len(v) == 0
    return False


def strip_diacritics(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def norm_id(v: Any) -> str:
    """Case-, diacritic- and punctuation-insensitive form."""
    s = strip_diacritics(str(v)).casefold()
    return re.sub(r"[^0-9a-z]+", "", s)


def norm_text(v: Any) -> str:
    """Lower-case, diacritics stripped, punctuation removed, whitespace collapsed."""
    s = strip_diacritics(str(v)).casefold()
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


_NUM_JUNK = re.compile(r"(?i)\b(chf|fr\.?|sfr|usd|eur|\$|€)\b|[\s  ]")
_APOSTROPHES = "'’‘`´"


def parse_number(v: Any) -> Optional[Decimal]:
    """
    Parse amounts as they appear in Swiss documents and LLM output:
    "3540", "3'540", "3’540.00", "CHF 3,540", "3540 CHF", "12.50", "-980.00", 3540 (int).
    Rules for separators: apostrophes and spaces are thousands separators; when both
    "," and "." occur the LAST one is the decimal mark; a lone "," followed by exactly
    three digits at the end is a thousands separator, otherwise a decimal mark.
    A lone "." is always a decimal mark ("12.50"; note this makes "3.540" == 3.54).
    """
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float, Decimal)):
        return Decimal(str(v))
    s = str(v).strip()
    if not s:
        return None
    s = _NUM_JUNK.sub("", s)
    for a in _APOSTROPHES:
        s = s.replace(a, "")
    s = s.replace("CHF", "").replace("chf", "").strip()
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        if re.search(r",\d{3}$", s) and s.count(",") == 1:
            s = s.replace(",", "")
        else:
            s = s.replace(",", ".")
    if not re.fullmatch(r"[-+]?\d+(\.\d+)?", s):
        return None
    try:
        return Decimal(s)
    except InvalidOperation:
        return None


def parse_date(v: Any) -> Optional[date]:
    if v is None:
        return None
    s = str(v).strip()
    for rx in DATE_FORMATS:
        m = rx.match(s)
        if m:
            try:
                return date(int(m["y"]), int(m["m"]), int(m["d"]))
            except ValueError:
                return None
    return None


def norm_enum(v: Any) -> str:
    s = norm_text(v)
    return ENUM_ALIASES.get(s, s)


def parse_bool(v: Any) -> Optional[bool]:
    if isinstance(v, bool):
        return v
    if v is None:
        return None
    return BOOL_ALIASES.get(str(v).strip().casefold())


# ── schema ──────────────────────────────────────────────────────────────────
def load_schema(path: Optional[str | Path] = None) -> dict:
    p = Path(path) if path else DEFAULT_SCHEMA_PATH
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def generic_path(path: str) -> str:
    """'wealth.bankaccounts[1].balance' -> 'wealth.bankaccounts[*].balance'."""
    return re.sub(r"\[\d+\]", "[*]", path)


def field_type(schema: dict, path: str) -> Optional[str]:
    return schema.get("types", {}).get(generic_path(path))


def is_ignored(schema: dict, path: str) -> bool:
    g = generic_path(path)
    for pat in schema.get("ignore", []):
        if pat.endswith(".*"):
            if g == pat[:-2] or g.startswith(pat[:-1]):
                return True
        elif g == pat:
            return True
    return False


def is_estimate(schema: dict, persona: Optional[str], path: str) -> bool:
    if not persona:
        return False
    return generic_path(path) in schema.get("estimate", {}).get(persona, [])


# ── judge ───────────────────────────────────────────────────────────────────
JUDGE_RUBRIC = """You are grading ONE free-text field of a Swiss (Zurich) tax return filled by an AI agent.
Decide whether the agent's value conveys the SAME FACT as the expected value for tax purposes.
Ignore differences in wording, language (German/English/French), abbreviations, punctuation and
added detail, as long as nothing is contradicted. Do NOT accept a value that names a different
entity, amount, route, or omits something the expected value requires.

Field: {path}
Expected value: {gt}
Agent value: {sub}
Ground-truth note (context, may be empty): {note}

Answer with exactly one word: YES or NO."""


def make_judge(llm_call: Callable[[str], str], cache_path: Optional[str | Path] = None):
    """
    Wrap any `llm_call(prompt) -> str` into a cached judge.
    The returned callable has signature judge(path, sub, gt, note) -> bool.
    Verdicts are cached in a JSON file keyed by sha1(path|sub|gt) so reruns are free.
    """
    cache_file = Path(cache_path) if cache_path else REPO / ".eval_judge_cache.json"
    try:
        cache = json.loads(cache_file.read_text(encoding="utf-8")) if cache_file.exists() else {}
    except Exception:
        cache = {}

    def judge(path: str, sub: Any, gt: Any, note: str = "") -> bool:
        key = hashlib.sha1(f"{path}|{sub}|{gt}".encode("utf-8")).hexdigest()
        if key in cache:
            return bool(cache[key]["verdict"])
        prompt = JUDGE_RUBRIC.format(path=path, gt=gt, sub=sub, note=note or "-")
        answer = str(llm_call(prompt)).strip().upper()
        verdict = answer.startswith("YES")
        cache[key] = {"path": path, "sub": str(sub), "gt": str(gt), "answer": answer[:40], "verdict": verdict}
        try:
            cache_file.write_text(json.dumps(cache, indent=1, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        return verdict

    return judge


# ── comparators (return (verdict, tier, detail)) ────────────────────────────
def cmp_number(gt, sub, estimate: bool):
    g, s = parse_number(gt), parse_number(sub)
    if g is None:
        return "wrong", "number:gt-unparseable", f"ground truth {gt!r} is not a number"
    if s is None:
        return "wrong", "number:unparseable", f"could not parse {sub!r} as a number"
    delta = abs(g - s)
    if delta < ABS_TOLERANCE:
        return "correct", "number:abs", f"|Δ|={delta}"
    if estimate and g != 0 and delta / abs(g) <= REL_TOLERANCE:
        return "correct", "number:rel", f"|Δ|={delta} ≤ 0.5 % (estimate field)"
    return "wrong", "number:abs", f"|Δ|={delta}"


def cmp_enum(gt, sub):
    g, s = norm_enum(gt), norm_enum(sub)
    if g == s:
        tier = "enum:exact" if norm_text(gt) == norm_text(sub) else "enum:alias"
        return "correct", tier, f"{sub!r} → {s!r}"
    return "wrong", "enum", f"{sub!r} → {s!r} ≠ {g!r}"


def cmp_bool(gt, sub):
    g, s = parse_bool(gt), parse_bool(sub)
    if s is None:
        return "wrong", "bool:unparseable", f"{sub!r}"
    return ("correct" if g == s else "wrong"), "bool", f"{sub!r} → {s}"


def cmp_date(gt, sub):
    g, s = parse_date(gt), parse_date(sub)
    if g is None:
        return "wrong", "date:gt-unparseable", f"ground truth {gt!r} not a date"
    if s is None:
        return "wrong", "date:unparseable", f"could not parse {sub!r} as a date"
    return ("correct" if g == s else "wrong"), "date:parsed", f"{s.isoformat()} vs {g.isoformat()}"


def cmp_id(gt, sub):
    same = norm_id(gt) == norm_id(sub)
    tier = "id:exact" if str(gt).strip() == str(sub).strip() else "id:normalized"
    return ("correct" if same else "wrong"), tier, f"{norm_id(sub)!r} vs {norm_id(gt)!r}"


def cmp_text(path, gt, sub, judge, note):
    gs, ss = str(gt).strip(), str(sub).strip()
    if gs.casefold() == ss.casefold():
        return "correct", "text:exact", ""
    if norm_text(gs) == norm_text(ss):
        return "correct", "text:normalized", ""
    fz = fuzz.token_set_ratio(norm_text(gs), norm_text(ss)) / 100.0
    if fz >= FUZZY_THRESHOLD:
        return "correct", f"text:fuzzy({fz:.2f})", "token-set ratio"
    if judge is not None:
        ok = judge(path, ss, gs, note)
        return ("correct" if ok else "wrong"), f"text:judge:{'yes' if ok else 'no'}", f"fuzzy {fz:.2f} < {FUZZY_THRESHOLD}, judge consulted"
    return "wrong", f"text:fuzzy({fz:.2f})", f"below {FUZZY_THRESHOLD}, no judge"


# ── flattening & row alignment ──────────────────────────────────────────────
def _leaves(node: Any, path: str = ""):
    if isinstance(node, dict):
        for k, v in node.items():
            if k.startswith("_"):
                continue
            yield from _leaves(v, f"{path}.{k}" if path else k)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from _leaves(v, f"{path}[{i}]")
    else:
        yield path, node


def _find_note(gt: dict, path: str) -> str:
    """Best-effort lookup of a `_meta._confidence` note for a field path."""
    conf = (gt.get("_meta") or {}).get("_confidence") or {}
    tokens = [t.casefold() for t in re.split(r"[.\[\]]+", path) if t and not t.isdigit()]
    best = ""
    for key, note in conf.items():
        k = key.casefold()
        if any(k == t or k in t or t in k for t in tokens[1:]) and len(key) > len(best):
            best = key
    return conf.get(best, "")


def _align_lists(gt: dict, sub: dict, schema: dict) -> dict:
    """
    Return a copy of `sub` where every list section that the ground truth also has is
    re-ordered so that row i matches GT row i (by the schema's list key, falling back to
    the original index). Unmatched submitted rows are appended after the GT rows so
    they surface as EXTRA.
    """
    out = json.loads(json.dumps(sub))
    for section, key in schema.get("list_keys", {}).items():
        parts = section.split(".")
        g_node, s_node = gt, out
        for p in parts[:-1]:
            g_node = g_node.get(p, {}) if isinstance(g_node, dict) else {}
            s_node = s_node.get(p, {}) if isinstance(s_node, dict) else {}
        g_rows = g_node.get(parts[-1]) if isinstance(g_node, dict) else None
        s_rows = s_node.get(parts[-1]) if isinstance(s_node, dict) else None
        if not isinstance(g_rows, list) or not isinstance(s_rows, list) or not g_rows or not s_rows:
            continue
        used, aligned = set(), []
        for i, g_row in enumerate(g_rows):
            g_key = norm_text((g_row or {}).get(key, "")) if isinstance(g_row, dict) else ""
            match = None
            if g_key:
                for j, s_row in enumerate(s_rows):
                    if j in used or not isinstance(s_row, dict):
                        continue
                    s_key = norm_text(s_row.get(key, ""))
                    if s_key and (s_key == g_key or fuzz.token_set_ratio(s_key, g_key) >= 85):
                        match = j
                        break
            if match is None and i < len(s_rows) and i not in used:
                match = i
            if match is not None:
                used.add(match)
                aligned.append(s_rows[match])
            else:
                aligned.append({})
        aligned.extend(s_rows[j] for j in range(len(s_rows)) if j not in used)
        s_node[parts[-1]] = aligned
    return out


# ── main entry point ────────────────────────────────────────────────────────
def extract_submission_data(agent_result: dict) -> dict:
    """agent_result['submission']['submission_json'] → dict (mirrors the notebook's unwrapping)."""
    submission = (agent_result or {}).get("submission", {})
    if isinstance(submission, dict):
        data = submission.get("submission_json", submission)
        return data if isinstance(data, dict) else {}
    return {}


def score(gt: dict, sub: dict, schema: Optional[dict] = None, judge=None, persona: Optional[str] = None) -> Report:
    schema = schema or load_schema()
    persona = persona or (gt.get("_meta") or {}).get("persona")
    sub = _align_lists(gt, sub or {}, schema)
    gt_leaves = dict(_leaves(gt))
    sub_leaves = dict(_leaves(sub))
    report = Report(persona=persona)

    # 1) every ground-truth leaf
    for path, gv in gt_leaves.items():
        ftype = field_type(schema, path)
        if ftype is None:
            report.untyped.append(path)
            ftype = "free_text"
        sv = sub_leaves.get(path)
        if is_empty(gv):
            continue  # scored in the EXTRA pass below
        report.total += 1
        if is_empty(sv):
            if ftype == "number" and parse_number(gv) == 0:
                report.rows.append(FieldResult(path, ftype, "correct", "number:zero-empty", gv, sv, "ground truth 0, field left empty"))
                report.correct += 1
            else:
                report.rows.append(FieldResult(path, ftype, "missing", "missing", gv, sv))
                report.missing += 1
            continue
        if ftype == "number":
            verdict, tier, detail = cmp_number(gv, sv, is_estimate(schema, persona, path))
        elif ftype == "enum":
            verdict, tier, detail = cmp_enum(gv, sv)
        elif ftype == "bool":
            verdict, tier, detail = cmp_bool(gv, sv)
        elif ftype == "date":
            verdict, tier, detail = cmp_date(gv, sv)
        elif ftype == "id":
            verdict, tier, detail = cmp_id(gv, sv)
        else:
            verdict, tier, detail = cmp_text(path, gv, sv, judge, _find_note(gt, path))
        report.rows.append(FieldResult(path, ftype, verdict, tier, gv, sv, detail))
        if verdict == "correct":
            report.correct += 1
        else:
            report.wrong += 1

    # 2) EXTRA: submitted, non-empty, where ground truth is empty or absent
    for path, sv in sub_leaves.items():
        if is_ignored(schema, path) or is_empty(sv):
            continue
        if isinstance(sv, bool) and sv is False:
            continue
        gv = gt_leaves.get(path)
        if gv is not None and not is_empty(gv):
            continue
        ftype = field_type(schema, path)
        if ftype is None:
            report.untyped.append(path)
        if ftype == "number" and parse_number(sv) == 0:
            continue  # "0" is not a claim
        report.rows.append(FieldResult(path, ftype or "free_text", "extra", "extra", gv, sv,
                                       "ground truth empty" if gv is not None else "not in ground truth"))
        report.extra += 1

    if report.total:
        report.raw_score = round(100.0 * report.correct / report.total, 1)
        report.score = round(100.0 * max(0.0, report.correct - EXTRA_PENALTY * report.extra) / report.total, 1)
    return report
