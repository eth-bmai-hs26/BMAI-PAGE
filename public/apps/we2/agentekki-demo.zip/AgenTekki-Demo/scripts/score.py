#!/usr/bin/env python3
"""
Swiss Tax Form Scoring Script
Compares an agent's submission.json against ground_truth.json for a persona.
All comparison logic lives in scripts/eval_lib.py (single source of truth);
this file is the CLI, the cause classification and the report layout.

Usage:
    python scripts/score.py anna_meier /path/to/submission.json
    python scripts/score.py --all /path/to/agent_output_dir/     # expects {persona}/submission.json
    python scripts/score.py anna_meier sub.json --judge           # LLM judge for free-text (needs scripts/eval_judge_llm.py or OPENROUTER_API_KEY)
"""

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.eval_lib import Report, extract_submission_data, load_schema, score  # noqa: E402

PERSONAS = [
    "anna_meier",
    "priya_chakraborty",
    "marco_laura_bernasconi",
    "thomas_elisabeth_widmer",
    "yuki_tanaka",
]
PERSONAS_DIR = REPO_ROOT / "personas"


# ---------------------------------------------------------------------------
# Error classification (unchanged heuristic)
# ---------------------------------------------------------------------------

def classify_likely_cause(path: str, persona: str) -> str:
    """
    Heuristic: classify whether an error is due to a missing calculation,
    info in documents, or info genuinely missing.
    """
    calculation_fields = {
        "flatrate", "berufsauslagen", "verpflegung",
        "zweiverdienerabzug", "medical", "netincome",
    }
    doc_fields = {
        "bruttolohn", "ahvcontributions", "bvgcontributions",
        "firstName", "lastName", "dateofbirth", "ahvnumber",
        "street", "streetNumber", "zip", "city",
        "maritalstatus", "occupation", "employer",
        "interest", "pillar3a", "fahrkosten", "donations",
        "ahvpension", "bvgpension", "capitalwithdrawals",
        "dividends", "revenue", "expenses",
        "eigenmietwert", "steuerwert", "balance",
        "weiterbildungskosten", "kinderbetreuungskosten",
        "schuldzinsen", "amount",
    }
    missing_fields = {
        "phone", "email", "religion", "workplace", "apartment",
        "insurance", "vehicles", "cashgold",
    }

    leaf = path.split(".")[-1]
    if "alimony" in path and persona == "yuki_tanaka":
        return "requires_calculation"
    if "freizuegigkeit" in path.lower() or "freizügigkeit" in path.lower():
        return "info_in_documents"
    section = path.split(".")[1] if "." in path else ""
    if leaf in calculation_fields or section in calculation_fields:
        return "requires_calculation"
    if leaf in missing_fields:
        return "info_missing"
    if leaf in doc_fields:
        return "info_in_documents"
    return "info_in_documents"


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------

def load_submission(submission_path: str) -> dict:
    with open(submission_path, encoding="utf-8") as f:
        data = json.load(f)
    # accept a bare submission_json, a submit_form() result, or a whole agent_result
    if isinstance(data, dict) and "submission_json" in data:
        return data["submission_json"] or {}
    if isinstance(data, dict) and "submission" in data:
        return extract_submission_data(data)
    return data


def report_to_result(report: Report, persona: str, submission_path: str) -> dict:
    verdict_to_type = {"wrong": "wrong_value", "missing": "missing", "extra": "extra"}
    errors = []
    for r in report.problems():
        errors.append({
            "path": r.path,
            "expected": r.gt,
            "got": r.sub,
            "error_type": verdict_to_type[r.verdict],
            "type": r.type,
            "tier": r.tier,
            "detail": r.detail,
            "likely_cause": classify_likely_cause(r.path, persona),
        })
    cause_counts = Counter(e["likely_cause"] for e in errors if e["error_type"] != "extra")
    return {
        "persona": persona,
        "submission_path": str(submission_path),
        "summary": {
            "total_ground_truth_fields": report.total,
            "correct": report.correct,
            "wrong_value": report.wrong,
            "missing": report.missing,
            "extra": report.extra,
            "score_percent": report.score,          # extra fields cost 0.5 each
            "raw_score_percent": report.raw_score,  # correct / total, no penalty
        },
        "cause_breakdown": dict(cause_counts),
        "untyped_fields": report.untyped,
        "errors": errors,
        "fields": [r.__dict__ for r in report.rows],
    }


def score_submission(persona: str, submission_path: str, judge=None) -> dict:
    gt_path = PERSONAS_DIR / persona / "ground_truth.json"
    if not gt_path.exists():
        print(f"ERROR: ground_truth.json not found at {gt_path}", file=sys.stderr)
        sys.exit(1)
    if not Path(submission_path).exists():
        print(f"ERROR: submission.json not found at {submission_path}", file=sys.stderr)
        sys.exit(1)
    with open(gt_path, encoding="utf-8") as f:
        ground_truth = json.load(f)
    submission = load_submission(submission_path)
    report = score(ground_truth, submission, load_schema(), judge=judge, persona=persona)
    return report_to_result(report, persona, submission_path)


# ---------------------------------------------------------------------------
# Output formatting
# ---------------------------------------------------------------------------

def print_summary_table(result: dict) -> None:
    s = result["summary"]
    sep = "=" * 72
    print(sep)
    print(f"  SCORING REPORT — {result['persona'].upper()}")
    print(sep)
    print(f"  Submission:    {result['submission_path']}")
    print(f"  Score:         {s['score_percent']}%  ({s['correct']}/{s['total_ground_truth_fields']} correct, "
          f"{s['extra']} extra × -0.5; raw {s['raw_score_percent']}%)")
    print(f"  Wrong value:   {s['wrong_value']}")
    print(f"  Missing:       {s['missing']}")
    print(f"  Extra:         {s['extra']}")
    if result.get("untyped_fields"):
        print(f"  UNTYPED:       {len(result['untyped_fields'])} field(s) missing from personas/field_schema.json")
    print()
    if result["cause_breakdown"]:
        print("  Error causes (wrong + missing only):")
        for cause, count in sorted(result["cause_breakdown"].items()):
            print(f"    {cause:<30} {count}")
        print()
    if result["errors"]:
        print("  Detailed errors:")
        print(f"  {'PATH':<44} {'TYPE':<11} {'EXPECTED':<22} {'GOT':<22} {'TIER':<18} CAUSE")
        print("  " + "-" * 140)
        for e in result["errors"]:
            exp = str(e["expected"])[:21] if e["expected"] not in (None, "") else "(empty)"
            got = str(e["got"])[:21] if e["got"] not in (None, "") else "(empty)"
            print(f"  {e['path'][:43]:<44} {e['error_type']:<11} {exp:<22} {got:<22} {e['tier'][:17]:<18} {e['likely_cause']}")
    else:
        print("  No errors found — perfect submission!")
    print(sep)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_judge():
    """Optional LLM judge: uses scripts/eval_judge_llm.py if present, else None."""
    try:
        from scripts.eval_judge_llm import llm_call  # type: ignore
    except Exception as exc:  # noqa: BLE001
        print(f"[judge] not available ({exc}); free-text below threshold will be marked wrong", file=sys.stderr)
        return None
    from scripts.eval_lib import make_judge
    return make_judge(llm_call)


def main() -> None:
    parser = argparse.ArgumentParser(description="Score a Swiss tax form submission against ground truth.")
    parser.add_argument("persona_or_flag", nargs="?", help="Persona name (e.g. anna_meier).")
    parser.add_argument("submission_path", nargs="?", help="Path to submission.json (single persona).")
    parser.add_argument("--all", metavar="DIR", default=None,
                        help="Score every persona: DIR contains {persona}/submission.json files.")
    parser.add_argument("--output-dir", default=None, help="Directory for comparison_report.json (default: next to submission).")
    parser.add_argument("--judge", action="store_true", help="Consult the LLM judge for free-text fields below the fuzzy threshold.")
    args = parser.parse_args()

    judge = build_judge() if args.judge else None
    all_results = []

    if args.all is not None:
        base_dir = Path(args.all)
        for persona in PERSONAS:
            sub_path = base_dir / persona / "submission.json"
            if not sub_path.exists():
                print(f"[SKIP] {persona}: no submission.json at {sub_path}")
                continue
            print(f"\n[SCORING] {persona} ...")
            result = score_submission(persona, str(sub_path), judge=judge)
            print_summary_table(result)
            all_results.append(result)
            out_dir = Path(args.output_dir) if args.output_dir else sub_path.parent
            out_dir.mkdir(parents=True, exist_ok=True)
            with open(out_dir / "comparison_report.json", "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2, ensure_ascii=False, default=str)
        if all_results:
            print("\n" + "=" * 72)
            print("  OVERALL SUMMARY")
            print("=" * 72)
            print(f"  {'PERSONA':<28} {'SCORE':>7} {'CORRECT':>8} {'WRONG':>6} {'MISSING':>8} {'EXTRA':>6}")
            for r in all_results:
                s = r["summary"]
                print(f"  {r['persona']:<28} {s['score_percent']:>6.1f}% {s['correct']:>8} {s['wrong_value']:>6} {s['missing']:>8} {s['extra']:>6}")
            avg = sum(r["summary"]["score_percent"] for r in all_results) / len(all_results)
            print(f"  {'AVERAGE':<28} {avg:>6.1f}%")
            print("=" * 72)
        return

    if not args.persona_or_flag or not args.submission_path:
        parser.error("usage: score.py <persona> <submission.json>  |  score.py --all DIR")
    persona = args.persona_or_flag
    if persona not in PERSONAS:
        print(f"ERROR: unknown persona {persona!r}. Choose from: {', '.join(PERSONAS)}", file=sys.stderr)
        sys.exit(1)
    result = score_submission(persona, args.submission_path, judge=judge)
    print_summary_table(result)
    out_dir = Path(args.output_dir) if args.output_dir else Path(args.submission_path).parent
    out_dir.mkdir(parents=True, exist_ok=True)
    report_path = out_dir / "comparison_report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False, default=str)
    print(f"  Report written to {report_path}")


if __name__ == "__main__":
    main()
